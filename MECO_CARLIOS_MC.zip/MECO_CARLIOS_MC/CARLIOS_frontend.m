function run = CARLIOS_frontend(s,mc_params)

%%% This is a box model coupling the carbon, lithium and osmium cycles. 
%%% It is a 0D, 5-box model, with a crustal reservoir, atmosphere
%%% and 3 ocean boxes (surface, high-latitude, deep). It is based on the
%%% model, CARMER, from Dal Corso et al. (2020), but with no Hg cycle.

%%% This version, CARLIOS, has been written by Alex Krause, 2021.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%   Define parameters   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%% set up global structures
global forcings
global stepnumber
global pars
global workingstate


%%%%%%%%%%%%%%%%%%%%%%% Constants %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

pars.f_circ_sv = 15; % Thermohaline speed - is 10 Sv in Carmer, 20 in Carcalc
pars.surf_area = 0.85; % Relative area of low latitude surface ocean
pars.high_area = 0.15; % Relative area of high latitude surface ocean
pars.tau = 10; % Timescale for gas exchange (years)
pars.gamma = 5; % Long-term climate sensitivity
pars.temp_0 = 288; % GAST for present day (= 15 degrees C)
pars.Ws = 7.4; % Solar luminosity
pars.RUN = 0.045; %0.038; % Climate-related runoff factor
pars.FERT = 0.4; % Land plant fertilisation factor
pars.ACT_bas = 0.0608; % Activation energy for basalt weathering
pars.ACT_gran = 0.0724; % Activation energy for granite weathering
pars.ACT_carb = 0.087; % Activation energy for carbonate weathering
pars.basfrac = 0.3; % fraction of silicates which are basaltic
pars.kacid = 7.4e-10; % Second dissociation constant
pars.sol_con = 0.8; % CaCO3 solubility constant - range of 0.45 to 1.15
pars.Saturation_0 = 3; % Present day CaCO3 saturation
pars.alpha_C = 27; % d13C fractionation
pars.d13c_c = 0; % d13c of carbonates
pars.d13c_g = -27; % d13c of organic carbon

% d13c of extra carbon input into atmosphere - likely erupted through
% carbonate rich rocks, thus assume that CO2 composition likely mixed
% between canonical -5 per mille input into exogenic system and 3 per mille
% of carbonates and therefore is more like the average d13C of seawater DIC
pars.d13c_input = 0;

pars.alpha_Li_aoc = 15; % d7Li fractionation during clay formation
pars.Os_split = 0.3; % Split contribution to riverine Os flux from silicate and oxidative weathering


%%%%%%%%%%%%%%%%%%%%% Flux values at present %%%%%%%%%%%%%%%%%%%%%%%%

% Carbon cycle
pars.Fmc_0 = 12e12; % Carbonate degassing
pars.F_wc_0 = 8e12; % Carbonate weathering
pars.F_sfw_0 = 0; % Seafloor weathering
pars.F_bc_0 = pars.F_wc_0 + pars.Fmc_0 - pars.F_sfw_0; % Carbonate burial - currently 16e12
pars.F_ws_0 = pars.F_bc_0 - pars.F_wc_0; % Silicate weathering - currently 8e12
pars.F_wgran_0 = pars.F_ws_0 * (1 - pars.basfrac); % granitic weathering
pars.F_wbas_0 = pars.F_ws_0 * pars.basfrac; % basaltic weathering

pars.Fmg_0 = 1.25e12; % Organic carbon degassing
pars.F_bg_sea_0 = 4.5e12; % Marine organic carbon burial
pars.F_bg_land_0 = 4.5e12; % Land organic carbon burial
pars.F_wg_0 = pars.F_bg_land_0 + pars.F_bg_sea_0 - pars.Fmg_0; % Organic carbon weathering - currently 7.75e12


% Lithium cycle
pars.riv_Li_0 = 8e9; % Riverine flux of lithium
pars.hyd_Li_0 = 6e9; % Hydrothermal flux of lithium
%%% For the combined sinks, see the CARLIOS.m file - this is because the
%%% sink flux size, to maintain mass balance, is dependent on the degassing 
%%% parameter which is part of the Monte Carlo simulation.

% Osmium cycle
pars.riv_Os_0 = 2405; %1500; % Riverine flux of osmium
pars.adust_Os_0 = 147.2; % Aeolian dust flux of osmium
pars.cdust_Os_0 = 176.1; % Cosmic dust flux of osmium
pars.lth_Os_0 = 197.14; % Low temp hydrothermal flux of osmium
pars.hth_Os_0 = 157.7; % High temp hydrothermal flux of osmium
pars.man_Os_0 = 1.0813; % Present day Os from subaerial weathering of ultramafic crust


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%% Montecarlo %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Additional input of CO2 to the atmosphere
if isfield(mc_params,'cinput_mc') == 1
    cinput_min = 6.87e12; % Low estimate 
    cinput_max = 1.07e13; % High estimate
  forcings.cinput = cinput_min + (cinput_max - cinput_min) .* rand;   
end 

% Normalised to present day erosion
if isfield(mc_params,'erosion_mc') == 1
    erosion_min = 0.5; % Change to 1 for Scenario B
    erosion_max = 1; % Change to 3 for Scenario B
  forcings.erosion = erosion_min + (erosion_max - erosion_min) .* rand;   
end 

% Erosion to weathering ratio
if isfield(mc_params,'ero2wea_mc') == 1
    ero2wea_min = 8;
    ero2wea_max = 40;
  forcings.ero2wea = ero2wea_min + (ero2wea_max - ero2wea_min) .* rand;   
end 

% Present day fraction of Li partitioned from the bedrock into the dissolved load
% via a Rayleigh distillation function, used in calculating F_riv_li
if isfield(mc_params,'rayleigh_mc') == 1
    rayleigh_min = 0.2823; % Value based on d7Li riv = 23pm / Use > value if using pre-MECO sw inferred from measured carbs +/- 3-5pm %0.4102;
    rayleigh_max = 0.2994; % Value based on d7Li sw = 31 and rearrange to find d7Li riv / Use > if using measured carbs %0.5586;
  forcings.rayleigh = rayleigh_min + (rayleigh_max - rayleigh_min) .* rand;   
end 

% Temperature dependent isotopic fractionation during clay formation
if isfield(mc_params,'tempfrac_mc') == 1
    tempfrac_min = -0.075;
    tempfrac_max = -0.15;
  forcings.tempfrac = tempfrac_min + (tempfrac_max - tempfrac_min) .* rand;   
end


% Background riverine 187Os/188Os
if isfield(mc_params,'dosriv_mc') == 1
    dosriv_min = 0.49;
    dosriv_max = 0.52;
  forcings.dosriv = dosriv_min + (dosriv_max - dosriv_min) .* rand;   
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%% Starting values %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%% Isotope values at present/starting values %%%%%%%%%%%%%%%%%%

pars.d13c_a_0 = -6.5; % d13c of atmosphere (per mille)
pars.d13c_DICs_0 = 2; % d13c of low latitude surface ocean (per mille)
pars.d13c_DICh_0 = 2; % d13c of high latitude surface ocean (per mille)
pars.d13c_DICd_0 = 2; % d13c of deep ocean (per mille)

pars.d7Li_s_0 = 26; %31; % d7Li of low latitude surface ocean (per mille)
pars.d7Li_h_0 = 26; %31; % d7Li of high latitude surface ocean (per mille)
pars.d7Li_d_0 = 26; %31; % d7Li of deep ocean (per mille)

pars.dOs_s_0 = 0.515; %1.05; % 187Os/188Os of low latitude surface ocean (per mille)
pars.dOs_h_0 = 0.515; %1.05; % 187Os/188Os of high latitude surface ocean (per mille)
pars.dOs_d_0 = 0.515; %1.05; % 187Os/188Os of deep ocean (per mille)


%%%%%% Present day/starting reservoir sizes (moles unless stated) %%%%%%%%

pars.water_s = 3.07e16; % low latitude surface ocean volume (m3)
pars.water_h = 1.35e16; % high latitude surface ocean volume (m3)
pars.water_d = 1.35e18; % deep ocean volume (m3)
pars.water_t = pars.water_s + pars.water_h + pars.water_d; % total ocean volume (m3)
pars.O_0 = 3.8e19; % Present day O2 in the atmosphere
pars.A_0 = 5e16; % Present day CO2 in the atmosphere
pars.DIC_s_0 = 6e16; % low latitude surface ocean DIC
pars.DIC_h_0 = 3e16; % high latitude surface ocean DIC
pars.DIC_d_0 = 3e18; % deep ocean DIC
pars.ALK_s_0 = 6e16; % low latitude surface ocean ALK
pars.ALK_h_0 = 3e16; % high latitude surface ocean ALK
pars.ALK_d_0 = 3e18; % deep ocean ALK
pars.Ca_s = 3.1e17; % low latitude surface ocean calcium (total ocean Ca in mM is ~10.3481)
pars.Ca_h = 1.4e17; % high latitude surface ocean calcium
pars.Ca_d = 1.4e19; % deep ocean calcium


pars.ocean_Li = 2.384e16; % total amount of lithium in the ocean at model start
% this is lower than present day (3.64e16) because starting with present day
% means that after spin-up the ocean is much more concentrated in Li - see SI
pars.Li_s_0 = pars.ocean_Li * (pars.water_s / pars.water_t); % low latitude surface ocean lithium
pars.Li_h_0 = pars.ocean_Li * (pars.water_h / pars.water_t); % high latitude surface ocean lithium
pars.Li_d_0 = pars.ocean_Li * (pars.water_d / pars.water_t); % deep ocean lithium

pars.ocean_Os = 6.5e7; %7.2e7; % total amount of osmium in the ocean at model start
pars.Os_s_0 = pars.ocean_Os * (pars.water_s / pars.water_t); % low latitude surface ocean osmium
pars.Os_h_0 = pars.ocean_Os * (pars.water_h / pars.water_t); % high latitude surface ocean osmium
pars.Os_d_0 = pars.ocean_Os * (pars.water_d / pars.water_t); % deep ocean osmium



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%   Initialise   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% set stepnumber to 1
stepnumber = 1;


%%%% model start state

pars.startstate(1) = pars.A_0;
pars.startstate(2) = pars.DIC_s_0;
pars.startstate(3) = pars.DIC_h_0;
pars.startstate(4) = pars.DIC_d_0;
pars.startstate(5) = pars.ALK_s_0;
pars.startstate(6) = pars.ALK_h_0;
pars.startstate(7) = pars.ALK_d_0;
pars.startstate(8) = pars.d13c_a_0 * pars.A_0;
pars.startstate(9) = pars.d13c_DICs_0 * pars.DIC_s_0;
pars.startstate(10) = pars.d13c_DICh_0 * pars.DIC_h_0;
pars.startstate(11) = pars.d13c_DICd_0 * pars.DIC_d_0;
pars.startstate(12) = pars.Li_s_0;
pars.startstate(13) = pars.Li_h_0;
pars.startstate(14) = pars.Li_d_0;
pars.startstate(15) = pars.d7Li_s_0 * pars.Li_s_0;
pars.startstate(16) = pars.d7Li_h_0 * pars.Li_h_0;
pars.startstate(17) = pars.d7Li_d_0 * pars.Li_d_0;
pars.startstate(18) = pars.Os_s_0;
pars.startstate(19) = pars.Os_h_0;
pars.startstate(20) = pars.Os_d_0;
pars.startstate(21) = pars.dOs_s_0 * pars.Os_s_0;
pars.startstate(22) = pars.dOs_h_0 * pars.Os_h_0;
pars.startstate(23) = pars.dOs_d_0 * pars.Os_d_0;
pars.startstate(24) = pars.Ca_s;
pars.startstate(25) = pars.Ca_h;
pars.startstate(26) = pars.Ca_d;

%%%%%%% model timeframe in years (0 = present day)

pars.whenstart = -55e6;
pars.whenend = -38e6;


%%%%%%% Show current timestep in command window? (1 = yes, 0 = no)
pars.telltime = 0;

%%%%%%% display every n model steps whilst running
pars.display_resolution = 10000;

%%%%%%% set maximum step size for solver
options = odeset('maxstep',1e3);

%%%% note model start time
tic

%%%%%%% run the system 
[rawoutput.T,rawoutput.Y] = ode15s(@CARLIOS,[pars.whenstart pars.whenend], pars.startstate, options, mc_params);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%   Postprocessing   %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%% takes 'workingstate' from model and turns into 'state' %%%%%%%

%%%% size of output
pars.output_length = length(rawoutput.T);

%%%%%%%%%% model finished output to screen
fprintf('Integration finished \t') ; fprintf('Total steps: %d \t' , stepnumber ) ; fprintf('Output steps: %d \n' , pars.output_length ) 
toc

%%%%%%%%% print final model states using final state for each timepoint
%%%%%%%%% during integration
fprintf('assembling state vectors... \t')
tic

%%%% trecords is index of shared values between ode15s output T vector and
%%%% model recorded workingstate t vector
[sharedvals,trecords] = intersect(workingstate.time,rawoutput.T,'stable') ;

%%%%%% assemble output state vectors
field_names = fieldnames(workingstate) ;
for numfields = 1:length(field_names)
    eval([' state.' char( field_names(numfields) ) ' = workingstate.' char( field_names(numfields) ) '(trecords) ; '])
end

%%%% Interpolate over timegrid to reduce output size

timegrid = -55:0.01:-38;
timegrid = timegrid';

state_fields = fieldnames(state);
% Interpolate model outputs to set time grid
for i=1:length(state_fields)
        varName(i) = matlab.lang.makeValidName(string(strcat(state_fields(i),"_gridded")));
        inter_state.(varName(i)) = interp1(state.time_myr,state.(string(state_fields(i))),timegrid);
        inter_state.(varName(i))(1:1350) = []; % Removes 55 to 41.51 Ma results
        inter_state.(varName(i))(252:end) = []; % Removes 39 to 38 Ma results
        clear varName
end

% Add state vectors to individual run structure

run.state = inter_state;

%%%%%% done message
fprintf('Done: ')
endtime = toc ;
fprintf('time (s): %d \n', endtime )


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%   Cleanup workspace   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear state
clear stepnumber
clear u
clear numfields
clear trecords
clear finalrecord
clear field_names
clear n
clear veclength
clear xvec
clear yvec
clear endtime
clear workingstate
clear state
clear inter_state
clear t


end
