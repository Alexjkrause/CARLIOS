31/01/2023 - Alex Krause

This folder contains the code and data files required to run the 2023 version of CARLIOS for the 
MECO (Krause et al., in revision with Nature Geoscience).

The files do not need to be moved - they are all in the correct place to be read into the model.

To run the model you need to do so from the CARLIOS_montecarlo.m file, but first you will need to 
download MATLAB's parallel computing toolbox. You can specify how many model runs you want to conduct.

The CARLIOS_frontend_MC.m file includes information about static parameters, reservoir sizes, defines the Monte Carlo variables, 
and contains the ODE solver. It also runs the post model run processing before passing all the data to the CARLIOS_montecarlo.m 
file for statistical analyses and figure plotting.

The CARLIOS_MC.m file contains all of the equations, including the differential ones, for the model.

The proxy_data.mat file contains the proxy data (CO2, temperature and pH) which the model will load and then use for figure plotting.

The site_data.mat file contains the data from Sites 1263 and U1333 as well as the smooth fits to the data. Again, the model will load
this file and use it for figure plotting.

Please direct any questions to Alex Krause: a.krause@ucl.ac.uk 
