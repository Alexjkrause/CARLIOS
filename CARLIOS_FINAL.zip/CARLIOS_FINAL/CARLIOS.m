function dy = CARLIOS(t,y,mc_params)

%%%%%%%%%%%%%%%%%%%%%%%%%  NOTE!!!  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% You need to comment in or out lines of code in this file if you   %%%
%%% want to switch between the different scenarios outlined in main   %%%
%%% text, Table 1                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%% Set up matrix for holding data

dy = zeros(29,1);

%%% Bring across globals

global forcings
global stepnumber
global pars
global workingstate


%% Transform dys into names for easy use

% Reservoirs

A = y(1); % Atmospheric CO2
DIC_s = y(2); % Low lat surface ocean DIC
DIC_h = y(3); % High lat surface ocean DIC
DIC_d = y(4); % Deep ocean DIC
ALK_s = y(5); % Low lat surface ocean ALK
ALK_h = y(6); % High lat surface ocean ALK
ALK_d = y(7); % Deep ocean ALK
Li_s = y(12); % Low lat surface ocean lithium
Li_h = y(13); % High lat surface ocean lithium
Li_d = y(14); % Deep ocean lithium
Os_s = y(18); % Low lat surface ocean osmium
Os_h = y(19); % High lat surface ocean osmium
Os_d = y(20); % Deep ocean osmium
Ca_s = y(24); % Low lat surface ocean calcium
Ca_h = y(25); % High lat surface ocean calcium
Ca_d = y(26); % Deep ocean calcium
Si_s = y(27); % Low lat surface ocean silicon
Si_h = y(28); % High lat surface ocean silicon
Si_d = y(29); % Deep ocean silicon


% Isotopes

d13c_a = y(8) / y(1); % Atmospheric d13c
d13c_DICs = y(9) / y(2); % Low lat surface ocean d13c
d13c_DICh = y(10) / y(3); % High lat surface ocean d13c
d13c_DICd = y(11) / y(4); % Deep ocean d13c
d7Li_s = y(15) / y(12); % Low lat surface ocean d7Li
d7Li_h = y(16) / y(13); % High lat surface ocean d7Li
d7Li_d = y(17) / y(14); % Deep ocean d7Li
dOs_s = y(21) / y(18); % Low lat surface ocean 187Os/188Os
dOs_h = y(22) / y(19); % High lat surface ocean 187Os/188Os
dOs_d = y(23) / y(20); % Deep ocean 187Os/188Os


%% Total concentrations in the ocean

Total_Li = Li_s + Li_h + Li_d;
Total_Os = Os_s + Os_h + Os_d;
Total_Ca = Ca_s + Ca_h + Ca_d;
Total_Si = Si_s + Si_h + Si_d;


%% Transform DIC and ALK into mol/m3

DIC_conc_s = DIC_s / pars.water_s;
DIC_conc_h = DIC_h / pars.water_h;
DIC_conc_d = DIC_d / pars.water_d;
ALK_conc_s = ALK_s / pars.water_s;
ALK_conc_h = ALK_h / pars.water_h;
ALK_conc_d = ALK_d / pars.water_d;


%% Transform Li, Os, Ca and Si into mol/m3

Li_conc_s = Li_s / pars.water_s;
Li_conc_h = Li_h / pars.water_h;
Li_conc_d = Li_d / pars.water_d;
Os_conc_s = Os_s / pars.water_s;
Os_conc_h = Os_h / pars.water_h;
Os_conc_d = Os_d / pars.water_d;
Ca_conc_s = Ca_s / pars.water_s;
Ca_conc_h = Ca_h / pars.water_h;
Ca_conc_d = Ca_d / pars.water_d;
Si_conc_s = Si_s / pars.water_s;
Si_conc_h = Si_h / pars.water_h;
Si_conc_d = Si_d / pars.water_d;


%% Time - geological time in Ma

time_myr = t * (1e-6);


%% Time-dependent forcings
% For the MECO most of these are assumed to be equal to the Present

%~~~~~~ Scenarios 1-7 ~~~~~~%
% f_L = 1.1; % carbonate land area

%~~~~~~ Scenario 8 ~~~~~~%
f_L = interp1([-55e6 -40.45e6 -40.4e6 -40.08e6 -40.03e6 -38e6],[1.1 1.1 0.9 0.7 1.1 1.1],t);


f_A_bas = 1.218; % basaltic land area

f_A_gran = 0.9974; % granitic land area

f_A_org = 1; % organic carbon land area

f_AWD = 1; % combined runoff effect due to changes in total land area and paleogeography

f_C = 1; % shift to deep sea carbonate formation due to pelagic calcifier evolution

if isfield(mc_params,'seafloor_mc') == 1
    f_G = forcings.seafloor;
else
    f_G = 1.45; % long-term tectonic degassing/metamorphism
end


%% CO2

RCO2 = (A / pars.A_0); % Normalised to present, CO2 in PAL

CO2atm = RCO2 * 280; % CO2 in ppm


%% Thermohaline speed

f_circ = (pars.f_circ_sv * 1e6) * 3.15e7; % Converts Sv to m3/yr


%% Transfer fluxes

% Carbon cycle

s2h_DIC = f_circ * DIC_conc_s; % Surface to high-latitude ocean DIC

h2d_DIC = f_circ * DIC_conc_h; % High-latitude to deep ocean DIC

d2s_DIC = f_circ * DIC_conc_d; % Deep to surface ocean DIC

s2h_ALK = f_circ * ALK_conc_s; % Surface to high-latitude ocean ALK

h2d_ALK = f_circ * ALK_conc_h; % High-latitude to deep ocean ALK

d2s_ALK = f_circ * ALK_conc_d; % Deep to surface ocean ALK


% Lithium cycle

s2h_Li = f_circ * Li_conc_s; % Surface to high-latitude ocean lithium

h2d_Li = f_circ * Li_conc_h; % High-latitude to deep ocean lithium

d2s_Li = f_circ * Li_conc_d; % Deep to surface ocean lithium


% Osmium cycle

s2h_Os = f_circ * Os_conc_s; % Surface to high-latitude ocean osmium

h2d_Os = f_circ * Os_conc_h; % High-latitude to deep ocean osmium

d2s_Os = f_circ * Os_conc_d; % Deep to surface ocean osmium


% Calcium cycle

s2h_Ca = f_circ * Ca_conc_s; % Surface to high-latitude ocean calcium

h2d_Ca = f_circ * Ca_conc_h; % High-latitude to deep ocean calcium

d2s_Ca = f_circ * Ca_conc_d; % Deep to surface ocean calcium


% Silicon cycle

s2h_Si = f_circ * Si_conc_s; % Surface to high-latitude ocean silicon

h2d_Si = f_circ * Si_conc_h; % High-latitude to deep ocean silicon

d2s_Si = f_circ * Si_conc_d; % Deep to surface ocean silicon


%% Temperature

GAST = pars.temp_0 + (pars.gamma * (log(RCO2) / log(2))) - (pars.Ws * (time_myr / -570));

temp_surf = 298 + ((2 / 3) * (GAST - pars.temp_0));

temp_high = max(275.5 + (GAST - pars.temp_0), 271);

temp_deep = max(275.5 + (GAST - pars.temp_0), 271);

atm_temp_change = GAST - pars.temp_0; % Change in atmospheric temperature from present day

surf_temp_change = temp_surf - 298;


%% Carbonate speciation

% Carbonate equilibrium constants

k_carb_surf = 5.75e-4 + (6e-6 * (temp_surf - 278));

k_carb_high = 5.75e-4 + (6e-6 * (temp_high - 278));

k_carb_deep = 5.75e-4 + (6e-6 * (temp_deep - 278));


% CO2 equilibrium constants

k_co2_surf = 0.035 + (0.0019 * (temp_surf - 278));

k_co2_high = 0.035 + (0.0019 * (temp_high - 278));

k_co2_deep = 0.035 + (0.0019 * (temp_deep - 278));


% Dissolved bicarbonate

HCO3_surf = (DIC_conc_s - ((DIC_conc_s)^2 - (ALK_conc_s * ((2 * DIC_conc_s) - ALK_conc_s) * (1 - (4 * k_carb_surf))))^0.5) / (1 - (4 * k_carb_surf));

HCO3_high = (DIC_conc_h - ((DIC_conc_h)^2 - (ALK_conc_h * ((2 * DIC_conc_h) - ALK_conc_h) * (1 - (4 * k_carb_high))))^0.5) / (1 - (4 * k_carb_high));

HCO3_deep = (DIC_conc_d - ((DIC_conc_d)^2 - (ALK_conc_d * ((2 * DIC_conc_d) - ALK_conc_d) * (1 - (4 * k_carb_deep))))^0.5) / (1 - (4 * k_carb_deep));


% Dissolved carbonate

CO3_surf = (ALK_conc_s - HCO3_surf) / 2;

CO3_high = (ALK_conc_h - HCO3_high) / 2;

CO3_deep = (ALK_conc_d - HCO3_deep) / 2;


% Dissolved CO2

pco2_surf = k_co2_surf * ((HCO3_surf^2) / CO3_surf);

pco2_high = k_co2_high * ((HCO3_high^2) / CO3_high);

pco2_deep = k_co2_deep * ((HCO3_deep^2) / CO3_deep);


% Acidity

Acid_surf = pars.kacid * (HCO3_surf / CO3_surf);

Acid_high = pars.kacid * (HCO3_high / CO3_high);

Acid_deep = pars.kacid * (HCO3_deep / CO3_deep);


% pH

pH_surf = -1 * log10(Acid_surf);

pH_high = -1 * log10(Acid_high);

pH_deep = -1 * log10(Acid_deep);


% CaCO3 solubility constant

Mg_Ca_0 = pars.Mg_conc_0 / pars.Ca_conc_0; % Present day Mg/Ca ratio


%~~~~~~ Scenarios 1-7 ~~~~~~%
% Mg_conc_s = pars.Mg_conc_MECO;
%~~~~~~ Scenario 8 ~~~~~~%
Mg_conc_s = interp1([-55e6 -40.45e6 -40.4e6 -40.08e6 -40.03e6 -38e6],[pars.Mg_conc_MECO pars.Mg_conc_MECO 0.8*pars.Mg_conc_MECO 0.6*pars.Mg_conc_MECO pars.Mg_conc_MECO pars.Mg_conc_MECO],t);


Mg_Ca_MECO = Mg_conc_s / Ca_conc_s; % Mg/Ca during the MECO 

% sol_con = pars.sol_con * (1 - pars.sol_alpha * (Mg_Ca_0 - Mg_Ca_MECO)); %
% Use this if you want to have the modern day solubility constant the same
% for all ocean boxes. If you do, then you will need to rename sol_con_s to
% sol_con etc in the saturation equations below

sol_con_s = 0.7 * (1 - pars.sol_alpha * (Mg_Ca_0 - Mg_Ca_MECO)); % Zeebe (2012) 
sol_con_h = 0.8 * (1 - pars.sol_alpha * (Mg_Ca_0 - Mg_Ca_MECO));
sol_con_d = 1.15 * (1 - pars.sol_alpha * (Mg_Ca_0 - Mg_Ca_MECO));

% Calcium carbonate saturation

Saturation_surf = (Ca_conc_s * CO3_surf) / sol_con_s;

Saturation_high = (Ca_conc_h * CO3_high) / sol_con_h;

Saturation_deep = (Ca_conc_d * CO3_deep) / sol_con_d;


% Lysocline depth

lydp = 5.8 + 50 * (CO3_deep - 0.1); % Walker and Kasting (1992) PPP

% Fractional area above the lysocline

froa = 0.1 + (lydp / 6)^2.5; % Walker and Kasting (1992) PPP


%% Air-sea exchanges

airsea_surf = pars.surf_area * pars.A_0 * (1 / pars.tau) * (RCO2 - pco2_surf);

airsea_high = pars.high_area * pars.A_0 * (1 / pars.tau) * (RCO2 - pco2_high);


%% Degassing

% Organic carbon degassing

Fmg = f_G * pars.Fmg_0;

% Carbonate carbon degassing

Fmc = f_G * pars.Fmc_0 * f_C;


%% Burial

sat_minus_1 = max(Saturation_surf - 1, 0);

F_bc_total = pars.F_bc_0 * (1 / pars.Saturation_0) * (sat_minus_1)^1.585; % Carbonate


%~~~~~~ Scenarios 1-4, 6-8 ~~~~~~%
shelf_frac = 0.26;
%~~~~~~ Scenario 5 ~~~~~~%
% shelf_frac = interp1([-55e6 -40.45e6 -40.08e6 -40.03e6 -38e6],[0.26 0.26 0.08 0.26 0.26],t);

F_bc_shelf = (1e13 * CO3_surf) / shelf_frac; % Carbonate burial on shelves


F_bc_deep = F_bc_total - F_bc_shelf;

F_bg_land = pars.F_bg_land_0; % Terrestrial Corg


%~~~~~~ Scenarios 1-3, 5-8 ~~~~~~%
bg_scale = 1;
%~~~~~~ Scenario 4 ~~~~~~%
% bg_scale = interp1([-55e6 -40.45e6 -40.08e6 -40.03e6 -38e6],[1 1 0.0001 1 1],t);

F_bg_sea = pars.F_bg_sea_0 * bg_scale; % Marine Corg


%% section break
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% UPLIFT AND ADDITIONAL CO2 INPUT SCENARIOS %%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Additional CO2 input pre and post MECO from Tibet
if isfield(mc_params,'back_co2_mc') == 1
    Tibet = forcings.back_co2;
else
    Tibet = 5.06e12; % Mol per yr
end


% Comment the following in/out as required:

%~~~~~~ Scenario 1 ~~~~~~%
% Additional CO2
% Iran = interp1([-55e6 -40.45e6 -40.08e6 -40.03e6 -38e6],[0 0 1e13 0 0],t);
% CO2_input = Tibet + Iran;

% Uplift
% f_R = 0.5;

%~~~~~~ Scenario 2 ~~~~~~%
% Additional CO2
% Iran =  0;
% CO2_input = Tibet + Iran;

% Uplift
% f_R = interp1([-55e6 -40.45e6 -40.08e6 -40.03e6 -38e6],[0.5 0.5 3 0.5 0.5],t);

%~~~~~~ Scenarios 3-5 ~~~~~~%
% Additional CO2
% Iran =  0;
% CO2_input = Tibet + Iran;

% Uplift
% f_R = 0.5;

%~~~~~~ Scenario 6 ~~~~~~%
% Additional CO2
% Iran = interp1([-55e6 -40.45e6 -40.08e6 -40.03e6 -38e6],[0 0 1e13 0 0],t);
% CO2_input = Tibet + Iran;

% Uplift
% f_R = interp1([-55e6 -40.45e6 -40.08e6 -40.03e6 -38e6],[0.5 0.5 3 0.5 0.5],t);

%~~~~~~ Scenarios 7-8 ~~~~~~%
% Additional CO2
Iran = interp1([-55e6 -40.45e6 -40.4e6 -40.08e6 -40.03e6 -38e6],[0 0 5e12 1e13 0 0],t);
CO2_input = Tibet + Iran;

% Uplift
f_R = interp1([-55e6 -40.45e6 -40.4e6 -40.08e6 -40.03e6 -38e6],[0.5 0.5 0.75 1 0.5 0.5],t);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% Weathering

% Temperature dependencies

f_Tbas =  exp(pars.ACT_bas * (GAST - pars.temp_0)) * ((1 + pars.RUN * (GAST - pars.temp_0))^0.65); % basalts

f_Tgran =  exp(pars.ACT_gran * (GAST - pars.temp_0)) * ( (1 + pars.RUN * (GAST - pars.temp_0))^0.65); % granites

f_Tcarb = 1 + (pars.ACT_carb * (GAST - pars.temp_0)); % carbonates

f_Tsfw = exp(pars.ACT_bas * (temp_deep - 271)); % seafloor basalt - no CO2 dependency


% CO2 dependency

f_CO2 = ((2 * RCO2) / (1 + RCO2))^pars.FERT; % In Ben's CARMER model this is f_biota and is 1


% Combined temperature and CO2 dependencies

f_Bbas = f_Tbas * f_CO2; % terrestrial basalts

f_Bgran = f_Tgran * f_CO2; % granites

f_Bcarb = f_Tcarb * f_CO2; % carbonates


% Silicate weathering

F_wbas = f_Bbas * pars.F_wbas_0 * f_A_bas * f_AWD; % Basalt weathering

F_wgran = f_Bgran * pars.F_wgran_0 * f_A_gran * f_AWD * f_R^0.33; % Granite weathering

F_ws = F_wbas + F_wgran; % Total silicate weathering


% Seafloor weathering

F_sfw = pars.F_sfw_0 * f_Tsfw * f_G; % assuming spreading rate = degassing


% Carbonate weathering

F_wc = f_Bcarb * pars.F_wc_0 * f_AWD * f_L * f_R^0.9;


% Organic carbon (oxidative) weathering
RO2 = 1.02; % Normalised atmospheric O2 levels - value based on Krause et al. (2018)
F_wg = pars.F_wg_0 * RO2^0.5 * f_A_org * f_R^0.33; % * ramping up;



%% Silicon cycle

% Fluxes only

F_adust_Si_s = pars.surf_area * pars.F_adust_Si_0; % Aeolian input of Si to low lat surface ocean

F_adust_Si_h = pars.high_area * pars.F_adust_Si_0; % Aeolian input of Si to high lat surface ocean

F_hyd_Si = f_G * pars.F_hyd_Si_0; % Hydrothermal input of Si

Si_conc_s_0 = pars.Si_s_0 / pars.water_s; % Low lat surface ocean silicon concentration at model initiation (mM)

F_opal = pars.F_opal_0 * (Si_conc_s / Si_conc_s_0); % Biogenic sink of Si


%~~~~~~ Scenarios 1-2, 4-8 ~~~~~~%
rw_scale = 1;
%~~~~~~ Scenario 3 ~~~~~~%
% rw_scale = interp1([-55e6 -40.45e6 -40.08e6 -40.03e6 -38e6],[1 1 4 1 1],t);

F_rw_Si = pars.F_rw_Si_0  * (Si_conc_s / Si_conc_s_0) * rw_scale; % Reverse weathering sink of Si


%% Lithium cycle fluxes and isotopes

% Change in isotopic fractionation during clay formation due to temperature
if isfield(mc_params,'tempfrac_mc') == 1
    clayfrac = forcings.tempfrac;
else
    clayfrac = -0.125;
end

% hydrothermal and sinks
F_hyd_Li = pars.hyd_Li_0 * f_G; % Hydrothermal flux of lithium
delta_hyd_Li = 8; % d7Li of hydrothermal input from Pogge et al. (2020)

Li_conc_s_0 = pars.Li_s_0 / pars.water_s; % Low lat surface ocean lithium concentration at model initiation (mM)
Li_conc_d_0 = pars.Li_d_0 / pars.water_d; % Deep ocean lithium concentration at model initiation (mM)

% Misra and Froelich (2012): ~30% present day Li removal from AOC and ~70% MAAC
F_aoc_Li = (0.3 * pars.F_sink_Li_0) * (Li_conc_d / Li_conc_d_0) * (F_sfw / pars.F_sfw_0); 

F_maac_Li = (0.7 * pars.F_sink_Li_0) * (Li_conc_s / Li_conc_s_0) * (F_rw_Si / pars.F_rw_Si_0);

delta_aoc = d7Li_s - (13 + (clayfrac * surf_temp_change));

delta_maac = d7Li_s - (20 + (clayfrac * surf_temp_change));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Rivers %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%~~~~ Caves-Rugenstein et al (2019) method ~~~~%%%%
a_li = 4.5;
b_li = 0.0575;
delta_rock_li = 1.5;
delta_sec_li = -17;
 
F_ws_tonnes = (5.5e8 / 8.7e12) * F_ws; % Assuming Gaillardet et al (1999) are right, however Tipper et al (2021)
% suggest this may be an overestimation, in which case instead of 5.5e8 it could be 3.96e8 (overestimation of F_ws by 28%)
% or 4.84e8 (overestimation of F_ws by 12%)

% Erosion to weathering ratio used for converting normalised uplift to
% erosion in tonnes per year, for the MECO
if isfield(mc_params,'ero2wea_mc') == 1
    erowea_MECO = forcings.ero2wea;
else
    erowea_MECO = 5;
end

%~~~~~~ Scenarios 1-6 ~~~~~~%
% erowea_ratio = 5;
%~~~~~~ Scenarios 7-8 ~~~~~~%
erowea_ratio = interp1([-55e6 -40.45e6 -40.4e6 -40.08e6 -40.03e6 -38e6],[5 5 erowea_MECO erowea_MECO 5 5],t);


erosion_tonnes = F_ws_tonnes * f_R * erowea_ratio; % Erosion in tonnes per year

WI = F_ws_tonnes / (F_ws_tonnes + erosion_tonnes); % Weathering intensity

delta_riv_Li = (delta_rock_li - (((1 - WI) / WI) * (-a_li * exp(-b_li / WI)))) + (clayfrac * atm_temp_change); % d7Li rivers

ray_frac = exp((delta_riv_Li - delta_rock_li) / delta_sec_li); % Fraction of Li partitioned from the bedrock into the 
% dissolved load via a Rayleigh distillation function, used in calculating F_riv_li

% Present day fraction of Li partitioned from the bedrock into the dissolved load
% via a Rayleigh distillation function, used in calculating F_riv_li
if isfield(mc_params,'rayleigh_mc') == 1
    ray_frac_0 = forcings.rayleigh;
else
    ray_frac_0 = 0.2994;
end

F_riv_Li = pars.riv_Li_0 * (F_ws / pars.F_ws_0) * (1 + (ray_frac - ray_frac_0)); % Riverine flux of lithium

% Contribution of riverine versus sinks to d7Li signature of the ocean
% if value is <1 then sinks are more important, but >1 rivers are
riv_v_sink = (F_riv_Li * delta_riv_Li) / ((F_aoc_Li * delta_aoc) + (F_maac_Li * delta_maac));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% Osmium cycle fluxes and isotopes

% Fluxes

F_ws_Os = pars.riv_Os_0 * pars.Os_split * f_AWD * (F_ws / pars.F_ws_0); % Weathering of Os in unradiogenic silicates

F_wg_Os = pars.riv_Os_0 * (1 - (pars.Os_split * f_AWD)) * (F_wg / pars.F_wg_0); % Weathering of Os in organic C rich lithologies

F_lth_Os = pars.lth_Os_0 * f_G; % Low temp hydrothermal input of Os

F_hth_Os = pars.hth_Os_0 * f_G; % High temp hydrothermal input of Os

F_adust_Os_s = pars.surf_area * pars.adust_Os_0; % Aeolian input of Os to low lat surface ocean

F_adust_Os_h = pars.high_area * pars.adust_Os_0; % Aeolian input of Os to high lat surface ocean

F_cdust_Os_s = pars.surf_area * pars.cdust_Os_0; % Cosmic input of Os to low lat surface ocean

F_cdust_Os_h = pars.high_area * pars.cdust_Os_0; % Cosmic input of Os to high lat surface ocean


%~~~~~~ Scenarios 1-6 ~~~~~~%
% F_mantle_Os = pars.man_Os_0;
%~~~~~~ Scenarios 7-8 ~~~~~~%
if isfield(mc_params,'mantleos_mc') == 1
    osman = forcings.mantleos;
else
    osman = 266;
end
F_mantle_Os = interp1([-55e6 -40.45e6 -40.4e6 -40.08e6 -40.03e6 -38e6],[pars.man_Os_0 pars.man_Os_0 osman osman pars.man_Os_0 pars.man_Os_0],t);


Os_conc_s_0 = pars.Os_s_0 / pars.water_s; % Low lat surface ocean osmium concentration at model initiation (mM)

F_sink_Os = pars.sink_Os_0 * (Os_conc_s / Os_conc_s_0); % Os sinks from the ocean


% Isotopes

% From IMB calculations it appears that pre-MECO rivers must be more
% unradiogenic than they are at the present day, possibly because uplift
% was half of what it is at present, thus there is less uplift of
% radiogenic rocks

if isfield(mc_params,'dosriv_mc') == 1
    dosriv = forcings.dosriv;
else
    dosriv = 0.505;
end

delta_wg_os = dosriv; % d187/188 Os of org-rich weathering

delta_ws_os = dosriv; % d187/188 Os of silicate weathering

delta_lth_os = 0.88; % d187/188 Os of low temp hydrothermal input flux

delta_hth_os = 0.13; % d187/188 Os of high temp hydrothermal input flux

delta_adust_os = 1.1; % d187/188 Os of aeolian dust input flux - ranges from 0.8 to 1.4, some use 1.05

delta_cdust_os = 0.12; % d187/188 Os of cosmic dust input flux

delta_man_os = 0.13; % d187/188 Os of weathering of fresh ultramafic rocks


%% Hydrothermal calcium input

F_hyd_Ca = f_G * pars.F_hyd_Ca_0; % Hydrothermal input of Ca


%% Reservoir calculations

%%%%% Carbon cycle %%%%%%%%%%%%%

dy(1) = Fmc + Fmg + F_wg - F_bg_land - F_wc - (2 * F_ws) - airsea_surf - airsea_high + CO2_input - (2 * F_sfw); % Atmospheric CO2

dy(2) = airsea_surf + d2s_DIC - s2h_DIC + (2 * F_wc) + (2 * F_ws) - F_bc_shelf - F_bg_sea; % Surface ocean DIC

dy(3) = airsea_high + s2h_DIC - h2d_DIC; % High-lat ocean DIC

dy(4) = h2d_DIC - d2s_DIC + (2 * F_sfw) - F_bc_deep; % Deep ocean DIC

dy(5) = d2s_ALK - s2h_ALK + (2 * F_wc) + (2 * F_ws) - (2 * F_bc_shelf) - (pars.sil2alk_rw * F_rw_Si); % Surface ocean alkalinity

dy(6) = s2h_ALK - h2d_ALK; % High-lat ocean alkalinity

dy(7) = h2d_ALK - d2s_ALK + (2 * F_sfw) - (2 * F_bc_deep); % Deep ocean alkalinity

dy(8) = (Fmc * pars.d13c_c) + (Fmg * pars.d13c_g) + (F_wg * pars.d13c_g) - (airsea_surf * d13c_a) - (airsea_high * d13c_a) - (F_bg_land * (d13c_a - pars.alpha_C)) - (F_wc * d13c_a) - (2 * F_ws * d13c_a) + (CO2_input * pars.d13c_input) - (d13c_DICs * 2 * F_sfw); % d13C of atmospheric CO2 * res

dy(9) = (airsea_surf * d13c_a) + (d2s_DIC * d13c_DICd) - (s2h_DIC * d13c_DICs) + (F_wc * d13c_a) + (F_wc * pars.d13c_c) + (2 * F_ws * d13c_a) - (F_bc_shelf * d13c_DICs) - (F_bg_sea * (d13c_DICs - pars.alpha_C)); % d13C of surface ocean DIC * res

dy(10) = (airsea_high * d13c_a) + (s2h_DIC * d13c_DICs) - (h2d_DIC * d13c_DICh); % d13C of high-lat ocean DIC * res

dy(11) = (h2d_DIC * d13c_DICh) - (d2s_DIC * d13c_DICd) + (d13c_DICs * 2 * F_sfw) - (F_bc_deep * d13c_DICd); % d13C of deep ocean DIC


%%%%%% Lithium cycle %%%%%%%%%%%

dy(12) = d2s_Li + F_riv_Li - F_maac_Li - s2h_Li; % Surface ocean lithium

dy(13) = s2h_Li - h2d_Li; % High lat ocean lithium

dy(14) = h2d_Li + F_hyd_Li - d2s_Li - F_aoc_Li; % Deep ocean lithium

dy(15) = (d2s_Li * d7Li_d) + (F_riv_Li * delta_riv_Li) - (F_maac_Li * delta_maac) - (s2h_Li * d7Li_s); % surf ocean d7li * res

dy(16) = (s2h_Li * d7Li_s) - (h2d_Li * d7Li_h); % d7Li of high lat surf ocean * res

dy(17) = (h2d_Li * d7Li_h) + (F_hyd_Li * delta_hyd_Li) - (d2s_Li * d7Li_d) - (F_aoc_Li * delta_aoc); % d7Li of deep ocean * res


%%%%%% Osmium cycle %%%%%%%%%%%%

dy(18) = d2s_Os + F_ws_Os + F_wg_Os + F_adust_Os_s + F_cdust_Os_s + F_mantle_Os - F_sink_Os - s2h_Os; % Surface ocean osmium

dy(19) = s2h_Os + F_adust_Os_h + F_cdust_Os_h - h2d_Os; % High lat ocean osmium

dy(20) = h2d_Os + F_lth_Os + F_hth_Os - d2s_Os; % Deep ocean osmium

dy(21) = (d2s_Os * dOs_d) + (F_ws_Os * delta_ws_os) + (F_wg_Os * delta_wg_os) + (F_adust_Os_s * delta_adust_os) + (F_cdust_Os_s * delta_cdust_os) + (F_mantle_Os * delta_man_os) - (F_sink_Os * dOs_s) - (s2h_Os * dOs_s); % d187Os/188Os surface ocean * res

dy(22) = (s2h_Os * dOs_s) + (F_adust_Os_h * delta_adust_os) + (F_cdust_Os_h * delta_cdust_os) - (h2d_Os * dOs_h); % d187Os/188Os high surface ocean * res

dy(23) = (h2d_Os * dOs_h) + (F_lth_Os * delta_lth_os) + (F_hth_Os * delta_hth_os) - (d2s_Os * dOs_d); % d187Os/188Os deep ocean * res


%%%%%%%%% Calcium cycle %%%%%%%%%%

dy(24) = d2s_Ca - s2h_Ca + F_wc + F_ws - F_bc_shelf - (0.2*F_rw_Si); % Surface ocean calcium

dy(25) = s2h_Ca - h2d_Ca; % High lat ocean calcium

dy(26) = h2d_Ca + F_hyd_Ca - d2s_Ca - F_bc_deep; % Deep ocean calcium


%%%%%%%%% Silicon cycle %%%%%%%%%%

dy(27) = d2s_Si + (pars.sil2alk_ws * (2 * F_ws)) + F_adust_Si_s - F_opal - F_rw_Si - s2h_Si; % Surface ocean silicon

dy(28) = s2h_Si + F_adust_Si_h - h2d_Si; % High lat surface ocean silicon

dy(29) = h2d_Si + F_hyd_Si - d2s_Si + (pars.sil2alk_ws * (2 * F_sfw)); % Deep ocean silicon


%% Working states

% Time
workingstate.time(stepnumber,1) = t;
workingstate.time_myr(stepnumber,1) = time_myr;

% Temperature
workingstate.GAST(stepnumber,1) = GAST;
workingstate.temp_deg(stepnumber,1) = GAST - 273;
workingstate.temp_surf(stepnumber,1) = temp_surf;
workingstate.temp_high(stepnumber,1) = temp_high;
workingstate.temp_deep(stepnumber,1) = temp_deep;

% Reservoirs (moles)
workingstate.CO2_moles(stepnumber,1) = A;
workingstate.DIC_s(stepnumber,1) = DIC_s;
workingstate.DIC_h(stepnumber,1) = DIC_h;
workingstate.DIC_d(stepnumber,1) = DIC_d;
workingstate.ALK_s(stepnumber,1) = ALK_s;
workingstate.ALK_h(stepnumber,1) = ALK_h;
workingstate.ALK_d(stepnumber,1) = ALK_d;
workingstate.Li_s(stepnumber,1) = Li_s;
workingstate.Li_h(stepnumber,1) = Li_h;
workingstate.Li_d(stepnumber,1) = Li_d;
workingstate.Os_s(stepnumber,1) = Os_s;
workingstate.Os_h(stepnumber,1) = Os_h;
workingstate.Os_d(stepnumber,1) = Os_d;
workingstate.Ca_s(stepnumber,1) = Ca_s;
workingstate.Ca_h(stepnumber,1) = Ca_h;
workingstate.Ca_d(stepnumber,1) = Ca_d;
workingstate.Si_s(stepnumber,1) = Si_s;
workingstate.Si_h(stepnumber,1) = Si_h;
workingstate.Si_d(stepnumber,1) = Si_d;
workingstate.Total_li(stepnumber,1) = Total_Li;
workingstate.Total_os(stepnumber,1) = Total_Os;
workingstate.Total_ca(stepnumber,1) = Total_Ca;
workingstate.Total_si(stepnumber,1) = Total_Si;


% Isotopes
workingstate.d13c_a(stepnumber,1) = d13c_a;
workingstate.d13c_DICs(stepnumber,1) = d13c_DICs;
workingstate.d13c_DICh(stepnumber,1) = d13c_DICh;
workingstate.d13c_DICd(stepnumber,1) = d13c_DICd;
workingstate.d7Li_s(stepnumber,1) = d7Li_s;
workingstate.d7Li_h(stepnumber,1) = d7Li_h;
workingstate.d7Li_d(stepnumber,1) = d7Li_d;
workingstate.delta_riv_Li(stepnumber,1) = delta_riv_Li;
workingstate.delta_aoc(stepnumber,1) = delta_aoc;
workingstate.delta_maac(stepnumber,1) = delta_maac;
workingstate.dOs_s(stepnumber,1) = dOs_s;
workingstate.dOs_h(stepnumber,1) = dOs_h;
workingstate.dOs_d(stepnumber,1) = dOs_d;


% Fluxes
workingstate.F_wbas(stepnumber,1) = F_wbas;
workingstate.F_wgran(stepnumber,1) = F_wgran;
workingstate.F_ws(stepnumber,1) = F_ws;
workingstate.F_sfw(stepnumber,1) = F_sfw;
workingstate.F_wc(stepnumber,1) = F_wc;
workingstate.F_wg(stepnumber,1) = F_wg;
workingstate.Fmg(stepnumber,1) = Fmg;
workingstate.Fmc(stepnumber,1) = Fmc;
workingstate.F_bc_shelf(stepnumber,1) = F_bc_shelf;
workingstate.F_bc_deep(stepnumber,1) = F_bc_deep;
workingstate.F_bc_total(stepnumber,1) = F_bc_total;
workingstate.F_bg_sea(stepnumber,1) = F_bg_sea;
workingstate.F_bg_land(stepnumber,1) = F_bg_land;
workingstate.s2h_DIC(stepnumber,1) = s2h_DIC;
workingstate.h2d_DIC(stepnumber,1) = h2d_DIC;
workingstate.d2s_DIC(stepnumber,1) = d2s_DIC;
workingstate.s2h_ALK(stepnumber,1) = s2h_ALK;
workingstate.h2d_ALK(stepnumber,1) = h2d_ALK;
workingstate.d2s_ALK(stepnumber,1) = d2s_ALK;
workingstate.airsea_surf(stepnumber,1) = airsea_surf;
workingstate.airsea_high(stepnumber,1) = airsea_high;
workingstate.CO2_input(stepnumber,1) = CO2_input;
workingstate.F_ws_tonnes(stepnumber,1) = F_ws_tonnes;
workingstate.erosion_tonnes(stepnumber,1) = erosion_tonnes;
workingstate.Iran(stepnumber,1) = Iran;

workingstate.F_riv_Li(stepnumber,1) = F_riv_Li;
workingstate.F_hyd_Li(stepnumber,1) = F_hyd_Li;
workingstate.F_aoc_Li(stepnumber,1) = F_aoc_Li;
workingstate.F_maac_Li(stepnumber,1) = F_maac_Li;
workingstate.s2h_Li(stepnumber,1) = s2h_Li;
workingstate.h2d_Li(stepnumber,1) = h2d_Li;
workingstate.d2s_Li(stepnumber,1) = d2s_Li;

workingstate.F_ws_Os(stepnumber,1) = F_ws_Os;
workingstate.F_wg_Os(stepnumber,1) = F_wg_Os;
workingstate.F_lth_Os(stepnumber,1) = F_lth_Os;
workingstate.F_hth_Os(stepnumber,1) = F_hth_Os;
workingstate.F_mantle_Os(stepnumber,1) = F_mantle_Os;
workingstate.F_sink_Os(stepnumber,1) = F_sink_Os;
workingstate.s2h_Os(stepnumber,1) = s2h_Os;
workingstate.h2d_Os(stepnumber,1) = h2d_Os;
workingstate.d2s_Os(stepnumber,1) = d2s_Os;

workingstate.s2h_Ca(stepnumber,1) = s2h_Ca;
workingstate.h2d_Ca(stepnumber,1) = h2d_Ca;
workingstate.d2s_Ca(stepnumber,1) = d2s_Ca;

workingstate.F_opal(stepnumber,1) = F_opal;
workingstate.F_rw_Si(stepnumber,1) = F_rw_Si;
workingstate.F_hyd_Si(stepnumber,1) = F_hyd_Si;
workingstate.s2h_Si(stepnumber,1) = s2h_Si;
workingstate.h2d_Si(stepnumber,1) = h2d_Si;
workingstate.d2s_Si(stepnumber,1) = d2s_Si;


% CO2 and carbonate system
workingstate.CO2_ppm(stepnumber,1) = CO2atm;
workingstate.HCO3_surf(stepnumber,1) = HCO3_surf;
workingstate.HCO3_high(stepnumber,1) = HCO3_high;
workingstate.HCO3_deep(stepnumber,1) = HCO3_deep;
workingstate.CO3_surf(stepnumber,1) = CO3_surf;
workingstate.CO3_high(stepnumber,1) = CO3_high;
workingstate.CO3_deep(stepnumber,1) = CO3_deep;
workingstate.pco2_surf(stepnumber,1) = pco2_surf;
workingstate.pco2_high(stepnumber,1) = pco2_high;
workingstate.pco2_deep(stepnumber,1) = pco2_deep;
workingstate.Acid_surf(stepnumber,1) = Acid_surf;
workingstate.Acid_high(stepnumber,1) = Acid_high;
workingstate.Acid_deep(stepnumber,1) = Acid_deep;
workingstate.pH_surf(stepnumber,1) = pH_surf;
workingstate.pH_high(stepnumber,1) = pH_high;
workingstate.pH_deep(stepnumber,1) = pH_deep;
workingstate.Saturation_surf(stepnumber,1) = Saturation_surf;
workingstate.Saturation_high(stepnumber,1) = Saturation_high;
workingstate.Saturation_deep(stepnumber,1) = Saturation_deep;
workingstate.DIC_conc_s(stepnumber,1) = DIC_conc_s;
workingstate.DIC_conc_h(stepnumber,1) = DIC_conc_h;
workingstate.DIC_conc_d(stepnumber,1) = DIC_conc_d;
workingstate.ALK_conc_s(stepnumber,1) = ALK_conc_s;
workingstate.ALK_conc_h(stepnumber,1) = ALK_conc_h;
workingstate.ALK_conc_d(stepnumber,1) = ALK_conc_d;
workingstate.shelf_frac(stepnumber,1) =  shelf_frac;
workingstate.lydp(stepnumber,1) = lydp;
workingstate.froa(stepnumber,1) = froa;
workingstate.Mg_conc_s(stepnumber,1) = Mg_conc_s;
workingstate.Mg_Ca_MECO(stepnumber,1) = Mg_Ca_MECO;

% Elemental concentrations
workingstate.Li_conc_s(stepnumber,1) = Li_conc_s;
workingstate.Li_conc_h(stepnumber,1) = Li_conc_h;
workingstate.Li_conc_d(stepnumber,1) = Li_conc_d;
workingstate.Os_conc_s(stepnumber,1) = Os_conc_s;
workingstate.Os_conc_h(stepnumber,1) = Os_conc_h;
workingstate.Os_conc_d(stepnumber,1) = Os_conc_d;
workingstate.Ca_conc_s(stepnumber,1) = Ca_conc_s;
workingstate.Ca_conc_h(stepnumber,1) = Ca_conc_h;
workingstate.Ca_conc_d(stepnumber,1) = Ca_conc_d;
workingstate.Si_conc_s(stepnumber,1) = Si_conc_s;
workingstate.Si_conc_h(stepnumber,1) = Si_conc_h;
workingstate.Si_conc_d(stepnumber,1) = Si_conc_d;

% Uplift, erosion, weathering intensity etc
workingstate.WI(stepnumber,1) = WI;
workingstate.f_R(stepnumber,1) = f_R;
workingstate.erowea_ratio(stepnumber,1) = erowea_ratio;
workingstate.riv_v_sink(stepnumber,1) = riv_v_sink;
workingstate.rw_scale(stepnumber,1) = rw_scale;
workingstate.bg_scale(stepnumber,1) = bg_scale;
workingstate.f_L(stepnumber,1) = f_L;


%%%% output timestep if specified
if pars.telltime ==1
    if mod(stepnumber,pars.display_resolution) == 0 
        %%%% print model state to screen
        fprintf('Model step: %d \t', stepnumber); fprintf('time: %d \n', time_myr)
    end
end



%%%% final action record current model step
stepnumber = stepnumber + 1;


end