%%%% Monte Carlo run for CARLIOS

clear mc_outputs
clear mc_params
clear n
clear options
clear stepnumber
clear pars
clear forcings
clear workingstate
clear state
clear rawoutput

timegrid = -41.5:0.01:-39;
timegrid = timegrid';


n = 5000; % Number of model runs


mc_params.seafloor_mc = 1;
mc_params.back_co2_mc = 1;
mc_params.ero2wea_mc = 1;
mc_params.rayleigh_mc = 1;
mc_params.tempfrac_mc = 1;
mc_params.dosriv_mc = 1;
mc_params.mantleos_mc = 1;


%% Run Parallel Loop to increase model efficiency 
%(note you can't use global variables within parfor and so monte carlo forcings should be created within CARLIOS_frontend if using this approach)
parfor s = 1:n
    disp(s)
    run(s).output = CARLIOS_frontend(s,mc_params); % Run CARLIOS
end

mc_params_fieldnames = fieldnames(mc_params);
fprintf('------------------------------- \n');
fprintf('Parameters used in Monte Carlo: \n');
disp(mc_params_fieldnames) % Print parameters used in Monte Carlo analysis
clear mc_params_fieldnames
fprintf('------------------------------- \n');

save('mc_runs.mat','run','-v7.3');


%% Process Outputs

state_fields = fieldnames(run(1).output.state);
% Make sure outputs have valid names, ready for adding to a single structure
 
for modelrun = n:-1:1
    for i=1:length(state_fields)
        varName(i) = matlab.lang.makeValidName(string(state_fields(i)));
        grid_outputs.(varName(i))(:,modelrun) = run(modelrun).output.state.(string(state_fields(i)));
        grid_outputs.(varName(i))(imag(grid_outputs.(varName(i))) ~= 0) = NaN; % Removes any NaNs
        clear varName
    end
end

clear run % Remove all state outputs once gridded to save space
 
grid_fields = fieldnames(grid_outputs);

% Add all gridded outputs to a single structure for cleanliness

fprintf('Creating Output Data Structure \n')

for ni=1:length(grid_fields)
    temps = string(grid_fields(ni));
    tempname = matlab.lang.makeValidName(strsplit(temps,'_gridded'));
    varName(ni) = tempname(1);
    mc_outputs.(varName(ni)) = grid_outputs.(string(grid_fields(ni)));

    % Calculate Max and Min Value at each Time Step for each Variable
    for i=1:length(timegrid)
        mc_outputs.max.(varName(ni))(i) = max(grid_outputs.(string(grid_fields(ni)))(i,:));
        mc_outputs.min.(varName(ni))(i) = min(grid_outputs.(string(grid_fields(ni)))(i,:));
    end
    mc_outputs.max.(varName(ni)) = mc_outputs.max.(varName(ni))'; % Flip from row to column for plotting
    mc_outputs.min.(varName(ni)) = mc_outputs.min.(varName(ni))'; % Flip from row to column for plotting
    clear varName temps tempname
end

fprintf('---------- ~ Done ~ ----------- \n')


clear grid_outputs % Clear gridded outputs to clean up workspace


% Calculate statistics

fprintf('Calculating Statistics \n')
tic

fields = fieldnames(mc_outputs);
fields(ismember(fields,'max')) = []; % Remove from fields cell array to avoid error in subsequent loop (i.e. dont want to calculate mean of the max data values)
fields(ismember(fields,'min')) = []; % Remove from fields cell array to avoid error in subsequent loop

for ni=1:length(fields)
    varname = string(fields(ni));
    for i = 1:length(timegrid)
        x = mc_outputs.(varname)(i,:);
        meanx = nanmean(x);    
        stdx = nanstd(x);
        mc_outputs.means.(varname)(i,:) = meanx;
        mc_outputs.stds.(varname)(i,:) = stdx;
        mc_outputs.min1.(varname)(i,:) = meanx - stdx;
        mc_outputs.plus1.(varname)(i,:) = meanx + stdx;
        clear x meanx stdx
    end
end

fprintf('---------- ~ Done ~ ----------- \n')
endtime = toc;
fprintf('time (s): %d \n', endtime)

fprintf('Plotting \n')

%%%%% Plot outputs %%%%%%%%%%%%%%%%%%%%

load site_data % Loads in data from 1263 and U1333 for plotting
load proxy_data % Loads in proxy data for plotting

ntime = -1 .* timegrid; % Changes -41.5 to -39 to 41.5 to 39 Ma

%%% Define colours for plotting
col_ran = [200 200 200] ./ 255;
lgreen = [0 255 0] ./ 255;
dgreen = [0 127 0] ./ 255;
gold = [237 177 32] ./ 255;
lblue = [19 159 255] ./ 255;
dblue = [0 114 189] ./ 255;
black = [0 0 0] ./ 255;
burgundy = [138 14 36] ./ 255;
cyan = [0 255 255] ./ 255;


figure

subplot(8,2,1)
hold on
box on
plot(ntime,mc_outputs.means.CO2_input,'k')
plot(ntime,mc_outputs.min1.CO2_input,'color',col_ran)
plot(ntime,mc_outputs.plus1.CO2_input,'color',col_ran)
xlim([39 41.5])
set(gca, 'XDir','reverse')
set(gca,'Xticklabel',[])
ylabel('Additional CO_2 input (Mol yr^{-1})')


subplot(8,2,2)
hold on
box on
plot(ntime,mc_outputs.means.f_R,'k')
xlim([39 41.5])
set(gca, 'XDir','reverse')
set(gca,'Xticklabel',[])
ylabel('Uplift (normalised)')


subplot(8,2,3)
hold on
box on
plot(ntime,mc_outputs.means.erowea_ratio,'k')
plot(ntime,mc_outputs.min1.erowea_ratio,'color',col_ran)
plot(ntime,mc_outputs.plus1.erowea_ratio,'color',col_ran)
xlim([39 41.5])
set(gca, 'XDir','reverse')
set(gca,'Xticklabel',[])
ylabel('Global E:W')


subplot(8,2,4)
hold on
box on
plot(ntime,mc_outputs.means.F_mantle_Os,'k')
plot(ntime,mc_outputs.min1.F_mantle_Os,'color',col_ran)
plot(ntime,mc_outputs.plus1.F_mantle_Os,'color',col_ran)
xlim([39 41.5])
set(gca, 'XDir','reverse')
set(gca,'Xticklabel',[])
ylabel('Os from eruptions (Mol yr^{-1})')
% ylim([1 1.2]) % Comment out for scenarios 7-8

subplot(8,2,5)
hold on
box on
plot(ntime,mc_outputs.means.bg_scale,'LineWidth',2,'color',cyan)
plot(ntime,mc_outputs.means.rw_scale,'LineStyle','--','LineWidth',1,'Color',gold)
plot(ntime,mc_outputs.means.f_L,'color',burgundy)
xlim([39 41.5])
set(gca, 'XDir','reverse')
set(gca,'Xticklabel',[])
ylabel('Scalings')
legend('F_{bg-sea}','F_{rw}','fL')
% ylim([0.9 1.2]) % Comment out for scenarios 3, 4, 8

subplot(8,2,6)
hold on
box on
plot(ntime,mc_outputs.means.Mg_Ca_MECO,'k')
plot(ntime,mc_outputs.min1.Mg_Ca_MECO,'color',col_ran)
plot(ntime,mc_outputs.plus1.Mg_Ca_MECO,'color',col_ran)
xlim([39 41.5])
set(gca, 'XDir','reverse')
set(gca,'Xticklabel',[])
ylabel('[Mg]_{sw}/[Ca]_{sw} (mmol/mmol)')


subplot(8,2,7)
hold on
box on
plot(ntime,mc_outputs.means.shelf_frac,'k')
xlim([39 41.5])
set(gca, 'XDir','reverse')
set(gca,'Xticklabel',[])
ylabel('Factor to apportion F_{bc} on shelves vs deep')


subplot(8,2,8)
hold on
box on
plot(time_co2ph,co2_calc,'MarkerSize',6,...
    'MarkerFaceColor',lblue,'Marker','.','LineStyle','none','Color',lblue)
% Comment in below for main text figure (Scenario 8)
plot(time_co2ph,co2_alk,'MarkerSize',6,'MarkerEdgeColor',lblue,...
    'MarkerFaceColor','none','Marker','square','LineStyle','none','Color',lblue)
plot(ntime, mc_outputs.means.CO2_ppm,'k')
plot(ntime,mc_outputs.min1.CO2_ppm,'color',col_ran)
plot(ntime,mc_outputs.plus1.CO2_ppm,'color',col_ran)
xlim([39 41.5])
set(gca, 'XDir','reverse')
set(gca,'Xticklabel',[])
ylabel('Atmospheric CO_2 (ppm)')
legend('Constant Ω_{calcite}')%,'Constant ALK')


subplot(8,2,9)
hold on
box on
plot(time_temp,temp,'MarkerSize',6,...
    'MarkerFaceColor',lblue,'Marker','.','LineStyle','none','Color',lblue)
plot(time_temp_smooth,temp_smooth,'LineWidth',2,'Color',dblue)
plot(ntime,mc_outputs.means.GAST-273,'k')
plot(ntime,mc_outputs.min1.GAST-273,'color',col_ran)
plot(ntime,mc_outputs.plus1.GAST-273,'color',col_ran)
xlim([39 41.5])
set(gca, 'XDir','reverse')
set(gca,'Xticklabel',[])
ylabel('GAST (°C)')


subplot(8,2,10)
hold on
box on
plot(time_co2ph,ph,'MarkerSize',6,...
    'MarkerFaceColor',burgundy,'Marker','.','LineStyle','none','Color',burgundy)
plot(time_ph_smooth,ph_smooth,'LineWidth',2,'Color',burgundy)
plot(ntime,mc_outputs.means.pH_surf,'color',gold)
plot(ntime,mc_outputs.means.pH_high,'color',lblue)
plot(ntime,mc_outputs.means.pH_deep,'color',dgreen)
xlim([39 41.5])
set(gca, 'XDir','reverse')
set(gca,'Xticklabel',[])
ylabel('Ocean pH')
legend('\delta^{11}B','\delta^{11}B','Low','High','Deep')


subplot(8,2,11)
hold on
box on
plot(ntime,mc_outputs.means.lydp,'k')
plot(ntime,mc_outputs.min1.lydp,'color',col_ran)
plot(ntime,mc_outputs.plus1.lydp,'color',col_ran)
xlim([39 41.5])
set(gca, 'XDir','reverse')
set(gca, 'YDir','reverse')
set(gca,'Xticklabel',[])
ylabel('Lysocline (km)')


subplot(8,2,12)
hold on
box on
plot(ntime,mc_outputs.means.Saturation_deep,'k')
plot(ntime,mc_outputs.min1.Saturation_deep,'color',col_ran)
plot(ntime,mc_outputs.plus1.Saturation_deep,'color',col_ran)
plot([39 41.5],[1 1],'LineStyle','--','LineWidth',1,'Color',lblue)
xlim([39 41.5])
set(gca, 'XDir','reverse')
set(gca,'Xticklabel',[])
ylabel('Deep ocean Ω_{calcite}')


subplot(8,2,13)
hold on
box on
plot(time_li_smooth,li_smooth,'color',lblue)
plot(time_li_smooth,li_min_smooth,'c')
plot(time_li_smooth,li_max_smooth,'c')
% Comment in below if you want to plot the individual site data
% errorbar(time_1263,li_1263,lierr_1263,'DisplayName','1263','MarkerSize',15,...
%     'MarkerFaceColor',dgreen,'Marker','.','LineStyle','none','Color',dgreen);
% errorbar(time_u1333,li_u1333,lierr_u1333,'DisplayName','U1333','MarkerSize',15,...
%     'MarkerFaceColor',gold,'Marker','.','LineStyle','none','Color',gold);
plot(ntime,mc_outputs.means.d7Li_s - 3,'k')
plot(ntime,mc_outputs.means.d7Li_s - 5,'k')
plot(ntime,mc_outputs.means.d7Li_s - 2,'color',col_ran)
plot(ntime,mc_outputs.means.d7Li_s - 6,'color',col_ran)
xlim([39 41.5])
set(gca, 'XDir','reverse')
set(gca,'Xticklabel',[])
ylabel('\delta^7Li_{carb} (‰)')


subplot(8,2,14)
hold on
box on
plot(ntime,mc_outputs.means.WI,'k')
plot(ntime,mc_outputs.min1.WI,'color',col_ran)
plot(ntime,mc_outputs.plus1.WI,'color',col_ran)
xlim([39 41.5])
set(gca, 'XDir','reverse')
set(gca,'Xticklabel',[])
ylabel('Weathering intensity')


subplot(8,2,15)
hold on
box on
plot(ntime,mc_outputs.means.riv_v_sink,'k')
plot(ntime,mc_outputs.min1.riv_v_sink,'color',col_ran)
plot(ntime,mc_outputs.plus1.riv_v_sink,'color',col_ran)
xlim([39 41.5])
set(gca, 'XDir','reverse')
xlabel('Time (Ma)')
ylabel('Rivers versus sinks (Li)')

subplot(8,2,16)
hold on
box on
plot(time_os_smooth,os_smooth,'color',lblue)
plot(time_os_smooth,os_min_smooth,'c')
plot(time_os_smooth,os_max_smooth,'c')
% Comment in below if you want to plot the individual site data
% errorbar(time_1263,os_1263,oserr_1263,'DisplayName','1263','MarkerSize',15,...
%     'MarkerFaceColor',dgreen,'Marker','.','LineStyle','none','Color',dgreen);
% errorbar(time_u1333,os_u1333,oserr_u1333,'DisplayName','U1333','MarkerSize',15,...
%     'MarkerFaceColor',gold,'Marker','.','LineStyle','none','Color',gold);
plot(ntime,mc_outputs.means.dOs_s,'k')
plot(ntime,mc_outputs.min1.dOs_s,'color',col_ran)
plot(ntime,mc_outputs.plus1.dOs_s,'color',col_ran)
xlim([39 41.5])
set(gca, 'XDir','reverse')
xlabel('Time (Ma)')
ylabel('^{187}Os/^{188}Os_{initial}')


%%%% Comment in the below for plotting d7Li of rivers vs WI for Fig. 4
%%%% in the main text (Scenario 8)
% For MECO 40.43 to 40.01 Ma
pre_WI = mc_outputs.means.WI(1:108);
MECO_WI = mc_outputs.means.WI(109:150);
post_WI = mc_outputs.means.WI(151:end);
pre_delta = mc_outputs.means.delta_riv_Li(1:108);
MECO_delta = mc_outputs.means.delta_riv_Li(109:150);
post_delta = mc_outputs.means.delta_riv_Li(151:end);

figure
subplot(1,2,1) % Plotted as a subplot so that the other subplot can be filled by the rest of Fig. 4
hold on
box on
plot(pre_WI,pre_delta,'^','color',col_ran)
plot(MECO_WI,MECO_delta,'+','color',gold)
plot(post_WI,post_delta,'v','color',cyan)
xlabel('Weathering intensity')
ylabel('\delta^7Li_{riv} (‰)')
legend('Pre MECO','MECO','Post MECO')

subplot(1,2,2)
box on

%%%% Comment in below if you want to plot all d7Li low latitude surface ocean at once
% figure
% hold on
% box on
% for j = 1:n
% plot(ntime,mc_outputs.d7Li_s(:,j))
% end
% set(gca, 'XDir','reverse')
% xlabel('Time (Ma)')
% ylabel('\delta^7Li_{sw} (‰)')
% xlim([39 41.5])



