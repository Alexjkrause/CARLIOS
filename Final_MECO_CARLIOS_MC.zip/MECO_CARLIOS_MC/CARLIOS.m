function dy = CARLIOS(t,y,mc_params)

%%% Set up matrix for holding data

dy = zeros(26,1);

%%% Bring across globals

global forcings
global stepnumber
global pars
global workingstate


%% Transform dys into names for easy use

% Reservoirs

A = y(1); % Atmospheric CO2
DIC_s = y(2); % Low lat surface ocean DIC
DIC_h = y(3); % High lat surface ocean DIC
DIC_d = y(4); % Deep ocean DIC
ALK_s = y(5); % Low lat surface ocean ALK
ALK_h = y(6); % High lat surface ocean ALK
ALK_d = y(7); % Deep ocean ALK
Li_s = y(12); % Low lat surface ocean lithium
Li_h = y(13); % High lat surface ocean lithium
Li_d = y(14); % Deep ocean lithium
Os_s = y(18); % Low lat surface ocean osmium
Os_h = y(19); % High lat surface ocean osmium
Os_d = y(20); % Deep ocean osmium
Ca_s = y(24); % Low lat surface ocean calcium
Ca_h = y(25); % High lat surface ocean calcium
Ca_d = y(26); % Deep ocean calcium


% Isotopes

d13c_a = y(8) / y(1); % Atmospheric d13c
d13c_DICs = y(9) / y(2); % Low lat surface ocean d13c
d13c_DICh = y(10) / y(3); % High lat surface ocean d13c
d13c_DICd = y(11) / y(4); % Deep ocean d13c
d7Li_s = y(15) / y(12); % Low lat surface ocean d7Li
d7Li_h = y(16) / y(13); % High lat surface ocean d7Li
d7Li_d = y(17) / y(14); % Deep ocean d7Li
dOs_s = y(21) / y(18); % Low lat surface ocean 187Os/188Os
dOs_h = y(22) / y(19); % High lat surface ocean 187Os/188Os
dOs_d = y(23) / y(20); % Deep ocean 187Os/188Os


%% Total concentrations in the ocean

Total_li = Li_s + Li_h + Li_d;
Total_os = Os_s + Os_h + Os_d;


%% Transform DIC and ALK into mol/m3

DIC_conc_s = DIC_s / pars.water_s;
DIC_conc_h = DIC_h / pars.water_h;
DIC_conc_d = DIC_d / pars.water_d;
ALK_conc_s = ALK_s / pars.water_s;
ALK_conc_h = ALK_h / pars.water_h;
ALK_conc_d = ALK_d / pars.water_d;


%% Transform Li, Os and Ca into mol/m3

Li_conc_s = Li_s / pars.water_s;
Li_conc_h = Li_h / pars.water_h;
Li_conc_d = Li_d / pars.water_d;
Os_conc_s = Os_s / pars.water_s;
Os_conc_h = Os_h / pars.water_h;
Os_conc_d = Os_d / pars.water_d;
Ca_conc_s = Ca_s / pars.water_s;
Ca_conc_h = Ca_h / pars.water_h;
Ca_conc_d = Ca_d / pars.water_d;


%% Time - geological time in Ma

time_myr = t * (1e-6);


%% Time-dependent forcings
% For the MECO most of these are assumed to be equal to the Present

f_L = 1; % carbonate land area

f_A_bas = 1; % basaltic land area

f_A_gran = 1; % granitic land area

f_A_org = 1; % organic carbon land area

f_AWD = 1; % combined runoff effect due to changes in total land area and paleogeography

f_C = 1; % shift to deep sea carbonate formation due to pelagic calcifier evolution

f_G = 1.43; % long-term tectonic degassing/metamorphism


%% CO2

RCO2 = (A / pars.A_0); % Normalised to present, CO2 in PAL

CO2atm = RCO2 * 280; % CO2 in ppm


%% section break
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% UPLIFT AND ADDITIONAL CO2 INPUT SCENARIOS %%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Monte Carlo instructions for uplift - make the change in the 
% CARLIOS_frontend.m file for Scenario B
if isfield(mc_params,'uplift_mc') == 1
    peak_f_R = forcings.uplift;
else
    peak_f_R = 1;
end

% Additional CO2 input pre and post MECO
backco2 = 5.06e12; % Mol per yr


% Comment the following in/out as required:


%~~~~~~ Test cases ~~~~~~%

% Monte Carlo instructions for additional CO2 input - for test cases 1 and
% 2 this is included in the Monte Carlo, but for test cases 3 and 4 the
% additional CO2 input is fixed and therefore cinput_mc needs to be 
% commented out in the CARLIOS_montecarlo.m file - see SI for details.
% if isfield(mc_params,'cinput_mc') == 1
%     addCO2 = forcings.cinput;
% else
%     addCO2 = 1.07e13; % < use for test 3, but for test4 use -> 2.14e13;
% end

% Uplift if MECO starts at 40.5 Ma
% f_R = interp1([-55e6 -40.5e6 -40.25e6 -40.0e6 -38e6],[0.5 0.5 peak_f_R 0.5 0.5],t);

% Uplift if MECO starts at 40.7 Ma
% f_R = interp1([-55e6 -40.7e6 -40.35e6 -40e6 -38e6],[0.5 0.5 peak_f_R 0.5 0.5],t);

% Additional CO2 input if MECO starts at 40.5 Ma
% CO2_input = interp1([-55e6 -40.5e6 -40.25e6 -40e6 -38e6],[backco2 backco2 addCO2 backco2 backco2],t);

% Additional CO2 input if MECO starts at 40.7 Ma
% CO2_input = interp1([-55e6 -40.7e6 -40.35e6 -40e6 -38e6],[backco2 backco2 addCO2 backco2 backco2],t);

%~~~~~~ Scenario A ~~~~~~%

% Additional CO2 input
Tibet = interp1([-55e6 -41.95e6 -40.95e6 -40.18e6 -39.43e6 -38e6],[3.47e12 3.47e12 5.06e12 3.26e12 3.804e12 3.804e12],t);
Iran = interp1([-55e6 -40.28e6 -40.18e6 -40.08e6 -38e6],[0 0 2.197e13 0 0],t);
CO2_input = Tibet + Iran;

% Uplift/erosion
f_R = interp1([-55e6 -40.7e6 -40.35e6 -40e6 -38e6],[0.5 0.5 peak_f_R 0.5 0.5],t);

%~~~~~~ Scenario B ~~~~~~%

% if isfield(mc_params,'cinput_mc') == 1
%     addCO2 = forcings.cinput;
% else
%      addCO2 = 2.282e13;
% end
% 
% % Additional CO2 input if MECO starts at 40.7 Ma
% CO2_input = interp1([-55e6 -40.7e6 -40.2e6 -40e6 -38e6],[backco2 backco2 addCO2 backco2 backco2],t);
% 
% % Uplift/erosion
% f_R = interp1([-55e6 -40.7e6 -40.35e6 -40e6 -38e6],[0.5 0.5 peak_f_R 0.5 0.5],t);

%~~~~~~ Scenario C ~~~~~~%

% if isfield(mc_params,'cinput_mc') == 1
%     addCO2 = forcings.cinput;
% else
%     addCO2 = 4.975e12;
% end
% 
% % Additional CO2 input
% CO2_input = addCO2;
% 
% % Uplift/erosion
% f_R = interp1([-55e6 -40.7e6 -40.35e6 -40e6 -38e6],[0.5 0.5 peak_f_R 0.5 0.5],t);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% Thermohaline speed

f_circ = (pars.f_circ_sv * 1e6) * 3.15e7; % Converts Sv to m3/yr


%% Transfer fluxes

% Carbon cycle

s2h_DIC = f_circ * DIC_conc_s; % Surface to high-latitude ocean DIC

h2d_DIC = f_circ * DIC_conc_h; % High-latitude to deep ocean DIC

d2s_DIC = f_circ * DIC_conc_d; % Deep to surface ocean DIC

s2h_ALK = f_circ * ALK_conc_s; % Surface to high-latitude ocean ALK

h2d_ALK = f_circ * ALK_conc_h; % High-latitude to deep ocean ALK

d2s_ALK = f_circ * ALK_conc_d; % Deep to surface ocean ALK


% Lithium cycle

s2h_Li = f_circ * Li_conc_s; % Surface to high-latitude ocean lithium

h2d_Li = f_circ * Li_conc_h; % High-latitude to deep ocean lithium

d2s_Li = f_circ * Li_conc_d; % Deep to surface ocean lithium


% Osmium cycle

s2h_Os = f_circ * Os_conc_s; % Surface to high-latitude ocean osmium

h2d_Os = f_circ * Os_conc_h; % High-latitude to deep ocean osmium

d2s_Os = f_circ * Os_conc_d; % Deep to surface ocean osmium


% Calcium cycle

s2h_Ca = f_circ * Ca_conc_s; % Surface to high-latitude ocean calcium

h2d_Ca = f_circ * Ca_conc_h; % High-latitude to deep ocean calcium

d2s_Ca = f_circ * Ca_conc_d;% Deep to surface ocean calcium


%% Temperature

GAST = pars.temp_0 + (pars.gamma * (log(RCO2) / log(2))) - (pars.Ws * (time_myr / -570));

temp_surf = 298 + ((2 / 3) * (GAST - pars.temp_0));

temp_high = max(275.5 + (GAST - pars.temp_0), 271);

temp_deep = max(275.5 + (GAST - pars.temp_0), 271);

atm_temp_change = GAST - pars.temp_0; % Change in atmospheric temperature from present day

surf_temp_change = temp_surf - 298;


%% Weathering

% Temperature dependencies

f_Tbas =  exp(pars.ACT_bas * (GAST - pars.temp_0)) * ((1 + pars.RUN * (GAST - pars.temp_0))^0.65); % basalts

f_Tgran =  exp(pars.ACT_gran * (GAST - pars.temp_0)) * ( (1 + pars.RUN * (GAST - pars.temp_0))^0.65); % granites

f_Tcarb = 1 + (pars.ACT_carb * (GAST - pars.temp_0)); % carbonates


% CO2 dependency

f_CO2 = ((2 * RCO2) / (1 + RCO2))^pars.FERT; % In Ben's CARMER model this is f_biota and is 1


% Combined temperature and CO2 dependencies

f_Bbas = f_Tbas * f_CO2; % basalts

f_Bgran = f_Tgran * f_CO2; % granites

f_Bcarb = f_Tcarb * f_CO2; % carbonates


% Silicate weathering

F_wbas = f_Bbas * pars.F_wbas_0 * f_A_bas * f_AWD; % Basalt weathering

F_wgran = f_Bgran * pars.F_wgran_0 * f_A_gran * f_AWD * f_R^0.33; % Granite weathering

F_ws = F_wbas + F_wgran; % Total silicate weathering


% Carbonate weathering

F_wc = f_Bcarb * pars.F_wc_0 * f_AWD * f_L * f_R^0.9;


% Organic carbon (oxidative) weathering
RO2 = 1.02; % Normalised atmospheric O2 levels - value based on Krause et al. (2018)
F_wg = pars.F_wg_0 * RO2^0.5 * f_A_org * f_R^0.33; % * ramping up;


%% Degassing

% Organic carbon degassing

Fmg = f_G * pars.Fmg_0;


% Carbonate carbon degassing

Fmc = f_G * pars.Fmc_0 * f_C;


%% Carbonate speciation

% Carbonate equilibrium constants

k_carb_surf = 5.75e-4 + (6e-6 * (temp_surf - 278));

k_carb_high = 5.75e-4 + (6e-6 * (temp_high - 278));

k_carb_deep = 5.75e-4 + (6e-6 * (temp_deep - 278));


% CO2 equilibrium constants

k_co2_surf = 0.035 + (0.0019 * (temp_surf - 278));

k_co2_high = 0.035 + (0.0019 * (temp_high - 278));

k_co2_deep = 0.035 + (0.0019 * (temp_deep - 278));


% Dissolved bicarbonate

HCO3_surf = (DIC_conc_s - ((DIC_conc_s)^2 - (ALK_conc_s * ((2 * DIC_conc_s) - ALK_conc_s) * (1 - (4 * k_carb_surf))))^0.5) / (1 - (4 * k_carb_surf));

HCO3_high = (DIC_conc_h - ((DIC_conc_h)^2 - (ALK_conc_h * ((2 * DIC_conc_h) - ALK_conc_h) * (1 - (4 * k_carb_high))))^0.5) / (1 - (4 * k_carb_high));

HCO3_deep = (DIC_conc_d - ((DIC_conc_d)^2 - (ALK_conc_d * ((2 * DIC_conc_d) - ALK_conc_d) * (1 - (4 * k_carb_deep))))^0.5) / (1 - (4 * k_carb_deep));


% Dissolved carbonate

CO3_surf = (ALK_conc_s - HCO3_surf) / 2;

CO3_high = (ALK_conc_h - HCO3_high) / 2;

CO3_deep = (ALK_conc_d - HCO3_deep) / 2;


% Dissolved CO2

pco2_surf = k_co2_surf * ((HCO3_surf^2) / CO3_surf);

pco2_high = k_co2_high * ((HCO3_high^2) / CO3_high);

pco2_deep = k_co2_deep * ((HCO3_deep^2) / CO3_deep);


% Acidity

Acid_surf = pars.kacid * (HCO3_surf / CO3_surf);

Acid_high = pars.kacid * (HCO3_high / CO3_high);

Acid_deep = pars.kacid * (HCO3_deep / CO3_deep);


% pH

pH_surf = -1 * log10(Acid_surf);

pH_high = -1 * log10(Acid_high);

pH_deep = -1 * log10(Acid_deep);


% Calcium carbonate saturation in the low latitude surface ocean

Saturation_surf = (Ca_conc_s * CO3_surf) / pars.sol_con;


%% Burial

sat_minus_1 = max(Saturation_surf - 1, 0);

F_bc = pars.F_bc_0 * (1 / pars.Saturation_0) * (sat_minus_1)^1.7; % Carbonate

F_bg_sea = pars.F_bg_sea_0; % Marine Corg

F_bg_land = pars.F_bg_land_0; % Terrestrial Corg


%% Air-sea exchanges

airsea_surf = pars.surf_area * pars.A_0 * (1 / pars.tau) * (RCO2 - pco2_surf);

airsea_high = pars.high_area * pars.A_0 * (1 / pars.tau) * (RCO2 - pco2_high);


%% Lithium cycle fluxes and isotopes

% Change in isotopic fractionation during clay formation due to temperature
if isfield(mc_params,'tempfrac_mc') == 1
    clayfrac = forcings.tempfrac;
else
    clayfrac = -0.125;
end

% hydrothermal and sinks
F_hyd_Li = pars.hyd_Li_0 * f_G; % Hydrothermal flux of lithium
delta_hyd_Li = 8; % d7Li of hydrothermal input from Pogge et al. (2020)

F_sink_Li_0 = pars.riv_Li_0 + F_hyd_Li; % Sink of lithium (into MAAC and AOC) at model initiation
Li_conc_s_0 = pars.Li_s_0 / pars.water_s; % Low lat surface ocean lithium concentration at model initiation (mM)

F_sink_Li = F_sink_Li_0 * (Li_conc_s / Li_conc_s_0); % Combined sink of lithium -> aoc + maac
delta_sink_Li = d7Li_s - (pars.alpha_Li_aoc + (clayfrac * surf_temp_change)); % d7Li of combined sinks (aoc + maac) with a temperature dependency - was prev. 0.15

%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Rivers %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%~~~~ Prescribed d7Li of rivers method as used in SI ~~~~%%%%
%~~~~~~~ Here the riverine flux is linked directly to silicate weathering
%~~~~~~~ and the d7Li is prescribed - these must be commented out if the
%~~~~~~~ Caves-Rugenstein et al method (below) is used.

% F_riv_Li = pars.riv_Li_0 * (F_ws / pars.F_ws_0); % Riverine flux of lithium
% NOTE different timings and peak d7Li values - see SI for more details
% delta_riv_Li = interp1([-55e6 -40.5e6 -40.25e6 -40e6 -38e6],[15 15 40 15 15],t); 
% delta_riv_Li = interp1([-55e6 -40.7e6 -40.35e6 -40e6 -38e6],[15 15 30 15 15],t);

%%%%~~~~ Caves-Rugenstein et al (2019) method - used in Scenarios A, B, C ~~~~%%%%
a_li = 4.5;
b_li = 0.0575;
delta_rock_li = 1.5;
delta_sec_li = -17;
 
F_ws_tonnes = (5.5e8 / 8.7e12) * F_ws; % Assuming Gaillardet et al (1999) are right, however Tipper et al (2021)
% suggest this may be an overestimation, in which case instead of 5.5e8 it could be 3.96e8 (overestimation of F_ws by 28%)
% or 4.84e8 (overestimation of F_ws by 12%) - worth further investigation

% Erosion to weathering ratio used for converting normalised erosion to
% tonnes per year, for the MECO
if isfield(mc_params,'ero2wea_mc') == 1
    erowea_MECO = forcings.ero2wea;
else
    erowea_MECO = 8; %25;
end

% Erosion to weathering ratio for the entire model run
erowea_ratio = interp1([-55e6 -40.7e6 -40.35e6 -40e6 -38e6],[8 8 erowea_MECO 8 8],t);

% Erosion to weathering ratio for model run attempts where the MECO starts at 40.5 Ma
% erowea_ratio = interp1([-55e6 -40.5e6 -40.25e6 -40e6 -38e6],[8 8 erowea_MECO 8 8],t);

erosion_tonnes = F_ws_tonnes * f_R * erowea_ratio; % Erosion in tonnes per year
WI = F_ws_tonnes / (F_ws_tonnes + erosion_tonnes); % Weathering intensity
delta_riv_Li = (delta_rock_li - (((1 - WI) / WI) * (-a_li * exp(-b_li / WI)))) + (clayfrac * atm_temp_change); % d7Li rivers
ray_frac = exp((delta_riv_Li - delta_rock_li) / delta_sec_li); % Fraction of Li partitioned from the bedrock into the 
% dissolved load via a Rayleigh distillation function, used in calculating F_riv_li

% Present day fraction of Li partitioned from the bedrock into the dissolved load
% via a Rayleigh distillation function, used in calculating F_riv_li
if isfield(mc_params,'rayleigh_mc') == 1
    ray_frac_0 = forcings.rayleigh;
else
    ray_frac_0 = 0.2994;
end

F_riv_Li = pars.riv_Li_0 * (F_ws / pars.F_ws_0) * (1 + (ray_frac - ray_frac_0)); % Riverine flux of lithium

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%% Osmium cycle fluxes and isotopes

% Fluxes

F_ws_Os = pars.riv_Os_0 * pars.Os_split * f_AWD * (F_ws / pars.F_ws_0); % Weathering of Os in unradiogenic silicates

F_wg_Os = pars.riv_Os_0 * (1 - (pars.Os_split * f_AWD)) * (F_wg / pars.F_wg_0); % Weathering of Os in organic C rich lithologies

F_lth_Os = pars.lth_Os_0 * f_G; % Low temp hydrothermal input of Os

F_hth_Os = pars.hth_Os_0 * f_G; % High temp hydrothermal input of Os

F_adust_Os_s = pars.surf_area * pars.adust_Os_0; % Aeolian input of Os to low lat surface ocean

F_adust_Os_h = pars.high_area * pars.adust_Os_0; % Aeolian input of Os to high lat surface ocean

F_cdust_Os_s = pars.surf_area * pars.cdust_Os_0; % Cosmic input of Os to low lat surface ocean

F_cdust_Os_h = pars.high_area * pars.cdust_Os_0; % Cosmic input of Os to high lat surface ocean

osman = 354.8; % Increase in Os from subaerial weathering of freshly ejected mantle material
F_mantle_Os = interp1([-55e6 -40.6e6 -40.5e6 -40.1e6 -40e6 -38e6],[pars.man_Os_0 pars.man_Os_0 osman osman pars.man_Os_0 pars.man_Os_0],t); % Subaerial weathering of ultramafic and juvenile crust

pars.sink_Os_0 = pars.riv_Os_0 + pars.adust_Os_0 + pars.cdust_Os_0 + F_lth_Os + F_hth_Os + pars.man_Os_0; % Sink of Os at model initiation
Os_conc_s_0 = pars.Os_s_0 / pars.water_s; % Low lat surface ocean osmium concentration at model initiation (mM)
F_sink_Os = pars.sink_Os_0 * (Os_conc_s / Os_conc_s_0); % Os sinks from the ocean

% Isotopes

%%%% Marine Corg rich sediments provide 187Os/186Os values from 8.2 to 8.9
%%%% in Ravizza and Turekian (1992). They can be converted to 187Os/188Os
%%%% values by multiplying by 0.12035, which results in a range of 0.9869
%%%% to 1.0711, however in the Lu et al. (2017) compilation the range is
%%%% wide from 1.24 to 0.08. In Lu et al. (2017) the present day riverine
%%%% flux is 1.2 to 1.5. For simplicity we've kept the 187Os/188Os for
%%%% silicate and org-rich weathering the same, and MC values are based on
%%%% some simple IMB calculations to obtain a pre-MECO 187Os/188Os seawater


if isfield(mc_params,'dosriv_mc') == 1
    dosriv = forcings.dosriv;
else
    dosriv = 0.505;
end

delta_wg_os = dosriv; % d187/188 Os of org-rich weathering
delta_ws_os = dosriv; % d187/188 Os of silicate weathering

delta_lth_os = 0.88; % d187/188 Os of low temp hydrothermal input flux

delta_hth_os = 0.13; % d187/188 Os of high temp hydrothermal input flux

delta_adust_os = 1.1; % d187/188 Os of aeolian dust input flux - ranges from 0.8 to 1.4, some use 1.05

delta_cdust_os = 0.12; % d187/188 Os of cosmic dust input flux

delta_man_os = 0.13; % d187/188 Os of weathering of fresh ultramafic rocks

%% Link between d7Li rivers, silicate weathering and CO2 - Scenario C (SI)
% Attempts to estimate what the flux of cations from silicate weathering is
% when new clay formation has resulted in more uptake of cations on/into
% clays and subsequent effect on CO2 levels. If this is used, you need to
% comment out/in the relevant reservoir calculations below.

F_ws_cat = F_ws * (16.5 / delta_riv_Li)^0.33;

%% Reservoir calculations

%%%%% Carbon cycle %%%%%%%%%%%%%

dy(1) = Fmc + Fmg + F_wg - F_bg_land - F_wc - (2 * F_ws) - airsea_surf - airsea_high + CO2_input; % Atmospheric CO2

% Cations version
% dy(1) = Fmc + Fmg + F_wg - F_bg_land - F_wc - (2 * F_ws_cat) - airsea_surf - airsea_high + CO2_input; % Atmospheric CO2

dy(2) = airsea_surf + d2s_DIC - s2h_DIC + (2 * F_wc) + (2 * F_ws) - F_bc - F_bg_sea; % Surface ocean DIC

dy(3) = airsea_high + s2h_DIC - h2d_DIC; % High-lat ocean DIC

dy(4) = h2d_DIC - d2s_DIC; % Deep ocean DIC

dy(5) = d2s_ALK - s2h_ALK + (2 * F_wc) + (2 * F_ws) - (2 * F_bc); % Surface ocean alkalinity

dy(6) = s2h_ALK - h2d_ALK; % High-lat ocean alkalinity

dy(7) = h2d_ALK - d2s_ALK; % Deep ocean alkalinity

dy(8) = (Fmc * pars.d13c_c) + (Fmg * pars.d13c_g) + (F_wg * pars.d13c_g) - (airsea_surf * d13c_a) - (airsea_high * d13c_a) - (F_bg_land * (d13c_a - pars.alpha_C)) - (F_wc * d13c_a) - (2 * F_ws * d13c_a) + (CO2_input * pars.d13c_input); % d13C of atmospheric CO2 * res

% Cations version
% dy(8) = (Fmc * pars.d13c_c) + (Fmg * pars.d13c_g) + (F_wg * pars.d13c_g) - (airsea_surf * d13c_a) - (airsea_high * d13c_a) - (F_bg_land * (d13c_a - pars.alpha_C)) - (F_wc * d13c_a) - (2 * F_ws_cat * d13c_a) + (CO2_input * pars.d13c_input); % d13C of atmospheric CO2 * res

dy(9) = (airsea_surf * d13c_a) + (d2s_DIC * d13c_DICd) - (s2h_DIC * d13c_DICs) + (F_wc * d13c_a) + (F_wc * pars.d13c_c) + (2 * F_ws * d13c_a) - (F_bc * d13c_DICs) - (F_bg_sea * (d13c_DICs - pars.alpha_C)); % d13C of surface ocean DIC * res

dy(10) = (airsea_high * d13c_a) + (s2h_DIC * d13c_DICs) - (h2d_DIC * d13c_DICh); % d13C of high-lat ocean DIC * res

dy(11) = (h2d_DIC * d13c_DICh) - (d2s_DIC * d13c_DICd); % d13C of deep ocean DIC


%%%%%% Lithium cycle %%%%%%%%%%%

dy(12) = d2s_Li + F_riv_Li - F_sink_Li - s2h_Li; % Surface ocean lithium

dy(13) = s2h_Li - h2d_Li; % High lat ocean lithium

dy(14) = h2d_Li + F_hyd_Li - d2s_Li; % Deep ocean lithium

dy(15) = (d2s_Li * d7Li_d) + (F_riv_Li * delta_riv_Li) - (F_sink_Li * delta_sink_Li) - (s2h_Li * d7Li_s); % surf ocean d7li * res

dy(16) = (s2h_Li * d7Li_s) - (h2d_Li * d7Li_h); % d7Li of high lat surf ocean * res

dy(17) = (h2d_Li * d7Li_h) + (F_hyd_Li * delta_hyd_Li) - (d2s_Li * d7Li_d); % d7Li of deep ocean * res


%%%%%% Osmium cycle %%%%%%%%%%%%

dy(18) = d2s_Os + F_ws_Os + F_wg_Os + F_adust_Os_s + F_cdust_Os_s + F_mantle_Os - F_sink_Os - s2h_Os; % Surface ocean osmium

dy(19) = s2h_Os + F_adust_Os_h + F_cdust_Os_h - h2d_Os; % High lat ocean osmium

dy(20) = h2d_Os + F_lth_Os + F_hth_Os - d2s_Os; % Deep ocean osmium

dy(21) = (d2s_Os * dOs_d) + (F_ws_Os * delta_ws_os) + (F_wg_Os * delta_wg_os) + (F_adust_Os_s * delta_adust_os) + (F_cdust_Os_s * delta_cdust_os) + (F_mantle_Os * delta_man_os) - (F_sink_Os * dOs_s) - (s2h_Os * dOs_s); % d187Os/188Os surface ocean * res

dy(22) = (s2h_Os * dOs_s) + (F_adust_Os_h * delta_adust_os) + (F_cdust_Os_h * delta_cdust_os) - (h2d_Os * dOs_h); % d187Os/188Os high surface ocean * res

dy(23) = (h2d_Os * dOs_h) + (F_lth_Os * delta_lth_os) + (F_hth_Os * delta_hth_os) - (d2s_Os * dOs_d); % d187Os/188Os deep ocean * res


%%%%%%%%% Calcium cycle %%%%%%%%%%

dy(24) = d2s_Ca - s2h_Ca + F_wc + F_ws - F_bc; % Surface ocean calcium

% Cations version

% dy(24) = d2s_Ca - s2h_Ca + F_wc + F_ws_cat - F_bc; % Surface ocean calcium

dy(25) = s2h_Ca - h2d_Ca; % High lat ocean calcium

dy(26) = h2d_Ca - d2s_Ca; % Deep ocean calcium


%% Working states

% Time
workingstate.time(stepnumber,1) = t;
workingstate.time_myr(stepnumber,1) = time_myr;

% Temperature
workingstate.GAST(stepnumber,1) = GAST;
workingstate.temp_deg(stepnumber,1) = GAST - 273;
workingstate.temp_surf(stepnumber,1) = temp_surf;
workingstate.temp_high(stepnumber,1) = temp_high;
workingstate.temp_deep(stepnumber,1) = temp_deep;

% Reservoirs (moles)
workingstate.CO2_moles(stepnumber,1) = A;
workingstate.DIC_s(stepnumber,1) = DIC_s;
workingstate.DIC_h(stepnumber,1) = DIC_h;
workingstate.DIC_d(stepnumber,1) = DIC_d;
workingstate.ALK_s(stepnumber,1) = ALK_s;
workingstate.ALK_h(stepnumber,1) = ALK_h;
workingstate.ALK_d(stepnumber,1) = ALK_d;
workingstate.Li_s(stepnumber,1) = Li_s;
workingstate.Li_h(stepnumber,1) = Li_h;
workingstate.Li_d(stepnumber,1) = Li_d;
workingstate.Os_s(stepnumber,1) = Os_s;
workingstate.Os_h(stepnumber,1) = Os_h;
workingstate.Os_d(stepnumber,1) = Os_d;
workingstate.Ca_s(stepnumber,1) = Ca_s;
workingstate.Ca_h(stepnumber,1) = Ca_h;
workingstate.Ca_d(stepnumber,1) = Ca_d;
workingstate.Total_li(stepnumber,1) = Total_li;
workingstate.Total_os(stepnumber,1) = Total_os;


% Isotopes
workingstate.d13c_a(stepnumber,1) = d13c_a;
workingstate.d13c_DICs(stepnumber,1) = d13c_DICs;
workingstate.d13c_DICh(stepnumber,1) = d13c_DICh;
workingstate.d13c_DICd(stepnumber,1) = d13c_DICd;
workingstate.d7Li_s(stepnumber,1) = d7Li_s;
workingstate.d7Li_h(stepnumber,1) = d7Li_h;
workingstate.d7Li_d(stepnumber,1) = d7Li_d;
workingstate.delta_riv_Li(stepnumber,1) = delta_riv_Li;
workingstate.dOs_s(stepnumber,1) = dOs_s;
workingstate.dOs_h(stepnumber,1) = dOs_h;
workingstate.dOs_d(stepnumber,1) = dOs_d;


% Fluxes
workingstate.F_wbas(stepnumber,1) = F_wbas;
workingstate.F_wgran(stepnumber,1) = F_wgran;
workingstate.F_ws(stepnumber,1) = F_ws;
workingstate.F_wc(stepnumber,1) = F_wc;
workingstate.F_wg(stepnumber,1) = F_wg;
workingstate.Fmg(stepnumber,1) = Fmg;
workingstate.Fmc(stepnumber,1) = Fmc;
workingstate.F_bc(stepnumber,1) = F_bc;
workingstate.F_bg_sea(stepnumber,1) = F_bg_sea;
workingstate.F_bg_land(stepnumber,1) = F_bg_land;
workingstate.s2h_DIC(stepnumber,1) = s2h_DIC;
workingstate.h2d_DIC(stepnumber,1) = h2d_DIC;
workingstate.d2s_DIC(stepnumber,1) = d2s_DIC;
workingstate.s2h_ALK(stepnumber,1) = s2h_ALK;
workingstate.h2d_ALK(stepnumber,1) = h2d_ALK;
workingstate.d2s_ALK(stepnumber,1) = d2s_ALK;
workingstate.airsea_surf(stepnumber,1) = airsea_surf;
workingstate.airsea_high(stepnumber,1) = airsea_high;
workingstate.CO2_input(stepnumber,1) = CO2_input;
workingstate.F_ws_tonnes(stepnumber,1) = F_ws_tonnes;
workingstate.erosion_tonnes(stepnumber,1) = erosion_tonnes;

workingstate.F_riv_Li(stepnumber,1) = F_riv_Li;
workingstate.F_hyd_Li(stepnumber,1) = F_hyd_Li;
workingstate.F_sink_Li(stepnumber,1) = F_sink_Li;
workingstate.s2h_Li(stepnumber,1) = s2h_Li;
workingstate.h2d_Li(stepnumber,1) = h2d_Li;
workingstate.d2s_Li(stepnumber,1) = d2s_Li;

workingstate.F_ws_Os(stepnumber,1) = F_ws_Os;
workingstate.F_wg_Os(stepnumber,1) = F_wg_Os;
workingstate.F_lth_Os(stepnumber,1) = F_lth_Os;
workingstate.F_hth_Os(stepnumber,1) = F_hth_Os;
workingstate.F_mantle_Os(stepnumber,1) = F_mantle_Os;
workingstate.F_sink_Os(stepnumber,1) = F_sink_Os;
workingstate.s2h_Os(stepnumber,1) = s2h_Os;
workingstate.h2d_Os(stepnumber,1) = h2d_Os;
workingstate.d2s_Os(stepnumber,1) = d2s_Os;

workingstate.s2h_Ca(stepnumber,1) = s2h_Ca;
workingstate.h2d_Ca(stepnumber,1) = h2d_Ca;
workingstate.d2s_Ca(stepnumber,1) = d2s_Ca;


% CO2, carbonate system, and other variables
workingstate.CO2_ppm(stepnumber,1) = CO2atm;
workingstate.HCO3_surf(stepnumber,1) = HCO3_surf;
workingstate.HCO3_high(stepnumber,1) = HCO3_high;
workingstate.HCO3_deep(stepnumber,1) = HCO3_deep;
workingstate.CO3_surf(stepnumber,1) = CO3_surf;
workingstate.CO3_high(stepnumber,1) = CO3_high;
workingstate.CO3_deep(stepnumber,1) = CO3_deep;
workingstate.pco2_surf(stepnumber,1) = pco2_surf;
workingstate.pco2_high(stepnumber,1) = pco2_high;
workingstate.pco2_deep(stepnumber,1) = pco2_deep;
workingstate.Acid_surf(stepnumber,1) = Acid_surf;
workingstate.Acid_high(stepnumber,1) = Acid_high;
workingstate.Acid_deep(stepnumber,1) = Acid_deep;
workingstate.pH_surf(stepnumber,1) = pH_surf;
workingstate.pH_high(stepnumber,1) = pH_high;
workingstate.pH_deep(stepnumber,1) = pH_deep;
workingstate.Saturation_surf(stepnumber,1) = Saturation_surf;
workingstate.DIC_conc_s(stepnumber,1) = DIC_conc_s;
workingstate.DIC_conc_h(stepnumber,1) = DIC_conc_h;
workingstate.DIC_conc_d(stepnumber,1) = DIC_conc_d;
workingstate.ALK_conc_s(stepnumber,1) = ALK_conc_s;
workingstate.ALK_conc_h(stepnumber,1) = ALK_conc_h;
workingstate.ALK_conc_d(stepnumber,1) = ALK_conc_d;

workingstate.Li_conc_s(stepnumber,1) = Li_conc_s;
workingstate.Li_conc_h(stepnumber,1) = Li_conc_h;
workingstate.Li_conc_d(stepnumber,1) = Li_conc_d;
workingstate.Os_conc_s(stepnumber,1) = Os_conc_s;
workingstate.Os_conc_h(stepnumber,1) = Os_conc_h;
workingstate.Os_conc_d(stepnumber,1) = Os_conc_d;
workingstate.Ca_conc_s(stepnumber,1) = Ca_conc_s;
workingstate.Ca_conc_h(stepnumber,1) = Ca_conc_h;
workingstate.Ca_conc_d(stepnumber,1) = Ca_conc_d;

workingstate.WI(stepnumber,1) = WI;
workingstate.f_R(stepnumber,1) = f_R;
workingstate.F_ws_cat(stepnumber,1) = F_ws_cat;


%%%% output timestep if specified
if pars.telltime ==1
    if mod(stepnumber,pars.display_resolution) == 0 
        %%%% print model state to screen
        fprintf('Model step: %d \t', stepnumber); fprintf('time: %d \n', time_myr)
    end
end



%%%% final action record current model step
stepnumber = stepnumber + 1;


end