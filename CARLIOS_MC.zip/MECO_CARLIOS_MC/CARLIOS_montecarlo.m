%%%% Monte Carlo run for CARLIOS

clear mc_outputs
clear mc_params
clear n
clear options
clear stepnumber
clear pars
clear forcings
clear workingstate
clear state
clear rawoutput

timegrid = -41.5:0.01:-39;
timegrid = timegrid';


n = 5000; % Number of model runs


mc_params.uplift_mc = 1;
mc_params.cinput_mc = 1;
mc_params.ero2wea_mc = 1;
mc_params.rayleigh_mc = 1;
mc_params.tempfrac_mc = 1;
mc_params.dosriv_mc = 1;


%% Run Parallel Loop to increase model efficiency 
%(note you can't use global variables within parfor and so monte carlo forcings should be created within CARLIOS_frontend if using this approach)
parfor s = 1:n
    disp(s)
    run(s).output = CARLIOS_frontend(s,mc_params); % Run CARLIOS
end

mc_params_fieldnames = fieldnames(mc_params);
fprintf('------------------------------- \n');
fprintf('Parameters used in Monte Carlo: \n');
disp(mc_params_fieldnames) % Print parameters used in Monte Carlo analysis
clear mc_params_fieldnames
fprintf('------------------------------- \n');

save('mc_runs.mat','run','-v7.3');


%% Process Outputs

state_fields = fieldnames(run(1).output.state);
% Make sure outputs have valid names, ready for adding to a single structure
 
for modelrun = n:-1:1
    for i=1:length(state_fields)
        varName(i) = matlab.lang.makeValidName(string(state_fields(i)));
        grid_outputs.(varName(i))(:,modelrun) = run(modelrun).output.state.(string(state_fields(i)));
        grid_outputs.(varName(i))(imag(grid_outputs.(varName(i))) ~= 0) = NaN; % Removes any NaNs
        clear varName
    end
end

clear run % Remove all state outputs once gridded to save space
 
grid_fields = fieldnames(grid_outputs);
% Add all gridded outputs to a single structure for cleanliness

fprintf('Creating Output Data Structure \n')

for ni=1:length(grid_fields)
    temps = string(grid_fields(ni));
    tempname = matlab.lang.makeValidName(strsplit(temps,'_gridded'));
    varName(ni) = tempname(1);
    mc_outputs.(varName(ni)) = grid_outputs.(string(grid_fields(ni)));
    % Calculate Max and Min Value at each Time Step for each Variable
    for i=1:length(timegrid)
        mc_outputs.max.(varName(ni))(i) = max(grid_outputs.(string(grid_fields(ni)))(i,:));
        mc_outputs.min.(varName(ni))(i) = min(grid_outputs.(string(grid_fields(ni)))(i,:));
    end
    mc_outputs.max.(varName(ni)) = mc_outputs.max.(varName(ni))'; % Flip from row to column for plotting
    mc_outputs.min.(varName(ni)) = mc_outputs.min.(varName(ni))'; % Flip from row to column for plotting
    clear varName temps tempname
end

fprintf('---------- ~ Done ~ ----------- \n')


clear grid_outputs % Clear gridded outputs to clean up workspace


% Calculate statistics

fprintf('Calculating Statistics \n')
tic

fields = fieldnames(mc_outputs);
fields(ismember(fields,'max')) = []; % Remove from fields cell array to avoid error in subsequent loop (i.e. dont want to calculate mean of the max data values)
fields(ismember(fields,'min')) = []; % Remove from fields cell array to avoid error in subsequent loop

for ni=1:length(fields)
    varname = string(fields(ni));
%     mc_outputs.CI95.(varname) = ones(length(mc_outputs.(varname)),2);
%     disp(ni)
%     for i = 1:length(mc_outputs.(varname))
    for i = 1:length(timegrid)
        x = mc_outputs.(varname)(i,:);
%         SEM = nanstd(x) ./ sqrt(length(x));               % Standard Error
%         ts = tinv([0.025  0.975],length(x)-1);      % T-Score
%         CI = nanmean(x) + ts * SEM;                      % Confidence Intervals
%         mc_outputs.CI95.(varname)(i,:) = CI ;
       
        meanx = nanmean(x);
%         medianx = nanmedian(x);
        stdx = nanstd(x);
%         mc_outputs.medians.(varname)(i,:) = medianx;
        mc_outputs.means.(varname)(i,:) = meanx;
        mc_outputs.stds.(varname)(i,:) = stdx;
        mc_outputs.min1.(varname)(i,:) = meanx - stdx;
        mc_outputs.plus1.(varname)(i,:) = meanx + stdx;
        
%         mc_outputs.CImin.(varname)(i,:) = mean(x) - (1.96 * (std(x) / sqrt(n)));
%         mc_outputs.CImax.(varname)(i,:) = mean(x) + (1.96 * (std(x) / sqrt(n)));
        clear x meanx stdx %medianx SEM ts CI 
    end
end

fprintf('---------- ~ Done ~ ----------- \n')
endtime = toc;
fprintf('time (s): %d \n', endtime)

fprintf('Plotting \n')

%%%%% Plot outputs %%%%%%%%%%%%%%%%%%%%

load site_data % Loads in data from 1263 and U1333 for plotting
load proxy_data % Loads in proxy data for plotting

ntime = -1 .* timegrid; % Changes -41.5 to -39 to 41.5 to 39 Ma

%%% Define colours for plotting
col_ran = [200 200 200] ./ 255;
dgreen = [0 127 0] ./ 255;
gold = [237 177 32] ./ 255;
lblue = [19 159 255] ./ 255;

figure
%%%% Atmospheric CO2
subplot(3,4,1)
hold on
box on
plot(ntime, mc_outputs.means.CO2_ppm,'k')
plot(ntime, mc_outputs.min1.CO2_ppm,'color',col_ran)
plot(ntime, mc_outputs.plus1.CO2_ppm,'color',col_ran)
% plot proxy data
plot(alktime,alkenone,'MarkerSize',7,...
    'MarkerFaceColor',gold,'Marker','v','LineStyle','none','Color',gold)
plot(stomtime,stomata,'MarkerSize',7,...
    'MarkerFaceColor',dgreen,'Marker','s','LineStyle','none','Color',dgreen)
plot(btime,boron_lowalk,'MarkerSize',10,...
    'MarkerFaceColor',lblue,'Marker','.','LineStyle','none','Color',lblue)
xlabel('Time (Ma)')
ylabel('Atmospheric CO_2 (ppm)')


%%%% Ocean DIC
subplot(3,4,2)
hold on
box on
plot(ntime,mc_outputs.means.DIC_conc_s,'r')
plot(ntime,mc_outputs.min1.DIC_conc_s,'r--')
plot(ntime,mc_outputs.plus1.DIC_conc_s,'r--')

plot(ntime,mc_outputs.means.DIC_conc_h,'c')
plot(ntime,mc_outputs.min.DIC_conc_h,'c--')
plot(ntime,mc_outputs.plus1.DIC_conc_h,'c--')

plot(ntime,mc_outputs.means.DIC_conc_d,'b')
plot(ntime,mc_outputs.min1.DIC_conc_d,'b--')
plot(ntime,mc_outputs.plus1.DIC_conc_d,'b--')
xlabel('Time (Ma)')
ylabel('DIC (mol m^{-3})')

%%%% Ocean ALK
subplot(3,4,3)
hold on
box on
plot(ntime,mc_outputs.means.ALK_conc_s,'r')
plot(ntime,mc_outputs.min1.ALK_conc_s,'r--')
plot(ntime,mc_outputs.plus1.ALK_conc_s,'r--')

plot(ntime,mc_outputs.means.ALK_conc_h,'c')
plot(ntime,mc_outputs.min1.ALK_conc_h,'c--')
plot(ntime,mc_outputs.plus1.ALK_conc_h,'c--')

plot(ntime,mc_outputs.means.ALK_conc_d,'b')
plot(ntime,mc_outputs.min1.ALK_conc_d,'b--')
plot(ntime,mc_outputs.plus1.ALK_conc_d,'b--')
xlabel('Time (Ma)')
ylabel('ALK (mol m^{-3})')

%%%% Ocean HCO3
subplot(3,4,4)
hold on
box on
plot(ntime,mc_outputs.means.HCO3_surf,'r')
plot(ntime,mc_outputs.min1.HCO3_surf,'r--')
plot(ntime,mc_outputs.plus1.HCO3_surf,'r--')

plot(ntime,mc_outputs.means.HCO3_high,'c')
plot(ntime,mc_outputs.min1.HCO3_high,'c--')
plot(ntime,mc_outputs.plus1.HCO3_high,'c--')

plot(ntime,mc_outputs.means.HCO3_deep,'b')
plot(ntime,mc_outputs.min1.HCO3_deep,'b--')
plot(ntime,mc_outputs.plus1.HCO3_deep,'b--')
xlabel('Time (Ma)')
ylabel('HCO_{3} (mol m^{-3})')

%%%% Ocean CO3
subplot(3,4,5)
hold on
box on
plot(ntime,mc_outputs.means.CO3_surf,'r')
plot(ntime,mc_outputs.min1.CO3_surf,'r--')
plot(ntime,mc_outputs.plus1.CO3_surf,'r--')

plot(ntime,mc_outputs.means.CO3_high,'c')
plot(ntime,mc_outputs.min1.CO3_high,'c--')
plot(ntime,mc_outputs.plus1.CO3_high,'c--')

plot(ntime,mc_outputs.means.CO3_deep,'b')
plot(ntime,mc_outputs.min1.CO3_deep,'b--')
plot(ntime,mc_outputs.plus1.CO3_deep,'b--')
xlabel('Time (Ma)')
ylabel('CO_{3} (mol m^{-3})')

%%%% Ocean H+
subplot(3,4,6)
hold on
box on
plot(ntime,mc_outputs.means.Acid_surf,'r')
plot(ntime,mc_outputs.min1.Acid_surf,'r--')
plot(ntime,mc_outputs.plus1.Acid_surf,'r--')

plot(ntime,mc_outputs.means.Acid_high,'c')
plot(ntime,mc_outputs.min1.Acid_high,'c--')
plot(ntime,mc_outputs.plus1.Acid_high,'c--')

plot(ntime,mc_outputs.means.Acid_deep,'b')
plot(ntime,mc_outputs.min1.Acid_deep,'b--')
plot(ntime,mc_outputs.plus1.Acid_deep,'b--')
xlabel('Time (Ma)')
ylabel('H^{+} (mol m^{-3})')

%%%% Ocean pH
subplot(3,4,7)
hold on
box on
plot(ntime,mc_outputs.means.pH_surf,'r')
plot(ntime,mc_outputs.min1.pH_surf,'r--')
plot(ntime,mc_outputs.plus1.pH_surf,'r--')
% plot(ntime,mc_outputs.means.pH_high,'c')
% plot(ntime,mc_outputs.min1.pH_high,'c--')
% plot(ntime,mc_outputs.plus1.pH_high,'c--')
plot(ntime,mc_outputs.means.pH_deep,'b')
plot(ntime,mc_outputs.min1.pH_deep,'b--')
plot(ntime,mc_outputs.plus1.pH_deep,'b--')

% plot proxy data
plot(phtime,ph,'MarkerSize',10,...
    'MarkerFaceColor',dgreen,'Marker','.','LineStyle','none','Color',dgreen)
xlabel('Time (Ma)')
ylabel('pH')

%%%% Temperature
subplot(3,4,8)
hold on
box on
plot(ntime,mc_outputs.means.temp_surf-273,'r')
plot(ntime,mc_outputs.min1.temp_surf-273,'r--')
plot(ntime,mc_outputs.plus1.temp_surf-273,'r--')

% plot(ntime,mc_outputs.means.temp_high-273,'c')
% plot(ntime,mc_outputs.min1.temp_high-273,'c--')
% plot(ntime,mc_outputs.plus1.temp_high-273,'c--')

plot(ntime,mc_outputs.means.temp_deep-273,'b')
plot(ntime,mc_outputs.min1.temp_deep-273,'b--')
plot(ntime,mc_outputs.plus1.temp_deep-273,'b--')

plot(ntime,mc_outputs.means.GAST-273,'k')
plot(ntime,mc_outputs.min1.GAST-273,'color',col_ran)
plot(ntime,mc_outputs.plus1.GAST-273,'color',col_ran)
% plot proxy data
plot(temptime,temp,'MarkerSize',10,...
    'MarkerFaceColor',lblue,'Marker','.','LineStyle','none','Color',lblue)
xlabel('Time (Ma)')
ylabel('Temperature (deg C)')

%%%% Degassing
subplot(3,4,9)
hold on
box on
plot(ntime,mc_outputs.means.Fmc,'c')
plot(ntime,mc_outputs.min1.Fmc,'--c')
plot(ntime,mc_outputs.plus1.Fmc,'--c')

plot(ntime,mc_outputs.means.Fmg,'r')
plot(ntime,mc_outputs.min1.Fmg,'--r')
plot(ntime,mc_outputs.plus1.Fmg,'--r')
xlabel('Time (Ma)')
ylabel('Degassing')

%%%% Continental weathering
subplot(3,4,10)
hold on
box on
plot(ntime,mc_outputs.means.F_wbas,'b')
plot(ntime,mc_outputs.means.F_wgran,'r')
plot(ntime,mc_outputs.means.F_ws,'k')
plot(ntime,mc_outputs.min1.F_ws,'color',col_ran)
plot(ntime,mc_outputs.plus1.F_ws,'color',col_ran)

plot(ntime,mc_outputs.means.F_wc,'c')
xlabel('Time (Ma)')
ylabel('Weathering')

%%%% Burial fluxes
subplot(3,4,11)
hold on
box on
plot(ntime,mc_outputs.means.F_bc,'c')
plot(ntime,mc_outputs.min1.F_bc,'--c')
plot(ntime,mc_outputs.plus1.F_bc,'--c')

plot(ntime,mc_outputs.means.F_bg_sea,'r')
plot(ntime,mc_outputs.means.F_bg_land,'b')
xlabel('Time (Ma)')
ylabel('Burial')

%%%% d13C
subplot(3,4,12)
hold on
box on
plot(ntime,mc_outputs.means.d13c_a,'k')
plot(ntime,mc_outputs.means.d13c_DICs,'r')
plot(ntime,mc_outputs.means.d13c_DICh,'c')
plot(ntime,mc_outputs.means.d13c_DICd,'b')
% plot proxy data
plot(d13ctime,d13c,'MarkerSize',10,...
    'MarkerFaceColor',lblue,'Marker','.','LineStyle','none','Color',lblue)
xlabel('Time (Ma)')
ylabel('\delta^{13}C values')


figure
%%%% Ocean Li
subplot(3,3,1)
hold on
box on
plot(ntime,mc_outputs.means.Li_conc_s,'r')
plot(ntime,mc_outputs.min1.Li_conc_s,'r--')
plot(ntime,mc_outputs.plus1.Li_conc_s,'r--')

plot(ntime,mc_outputs.means.Li_conc_h,'c')
plot(ntime,mc_outputs.min1.Li_conc_h,'c--')
plot(ntime,mc_outputs.plus1.Li_conc_h,'c--')

plot(ntime,mc_outputs.means.Li_conc_d,'b')
plot(ntime,mc_outputs.min1.Li_conc_d,'b--')
plot(ntime,mc_outputs.plus1.Li_conc_d,'b--')
xlabel('Time (Ma)')
ylabel('Dissolved Li (mol m^{-3})')

%%%% Li fluxes
subplot(3,3,2)
hold on
box on
plot(ntime,mc_outputs.means.F_riv_Li,'r')
plot(ntime,mc_outputs.min1.F_riv_Li,'r--')
plot(ntime,mc_outputs.plus1.F_riv_Li,'r--')

plot(ntime,mc_outputs.means.F_hyd_Li,'c')

plot(ntime,mc_outputs.means.F_sink_Li,'b')
plot(ntime,mc_outputs.min1.F_sink_Li,'b--')
plot(ntime,mc_outputs.plus1.F_sink_Li,'b--')
xlabel('Time (Ma)')
ylabel('Lithium fluxes (Mol yr^{-1})')

%%%% Li isotopes seawater
subplot(3,3,3)
hold on
box on
plot(ntime,mc_outputs.means.d7Li_s,'r')
plot(ntime,mc_outputs.min1.d7Li_s,'r--')
plot(ntime,mc_outputs.plus1.d7Li_s,'r--')

plot(ntime,mc_outputs.means.d7Li_h,'c')
plot(ntime,mc_outputs.means.d7Li_d,'b')
xlabel('Time (Ma)')
ylabel('\delta^7Li_{sw} (‰)')

%%%% Li isotopes precipitating carbonates from low lat surface
subplot(3,3,4)
hold on
box on
% plot this model
plot(ntime,mc_outputs.means.d7Li_s - 3,'k')
plot(ntime,mc_outputs.means.d7Li_s - 5,'k')
plot(ntime,mc_outputs.means.d7Li_s - 2,'color',col_ran)
plot(ntime,mc_outputs.means.d7Li_s - 6,'color',col_ran)
% if plotting the data
% errorbar(time1263,li1263,errli1263,'DisplayName','1263','MarkerSize',15,...
%     'MarkerFaceColor',dgreen,'Marker','.','LineStyle','none','Color',dgreen);
% errorbar(timeu1333,liu1333,errliu1333,'DisplayName','U1333','MarkerSize',15,...
%     'MarkerFaceColor',gold,'Marker','.','LineStyle','none','Color',gold);
% if plotting the running averages of combined sites
plot(timeboth,liavg,'color',lblue)
plot(timeboth,limin,'c')
plot(timeboth,limax,'c')
xlabel('Time (Ma)')
ylabel('\delta^7Li_{shallow carbs} (‰)')


%%%% Li isotopes vs WI
pre_WI = mc_outputs.means.WI(1:100);
MECO_WI = mc_outputs.means.WI(101:151);
post_WI = mc_outputs.means.WI(152:end);
pre_delta = mc_outputs.means.delta_riv_Li(1:100);
MECO_delta = mc_outputs.means.delta_riv_Li(101:151);
post_delta = mc_outputs.means.delta_riv_Li(152:end);
subplot(3,3,5)
hold on
box on
plot(pre_WI,pre_delta,'.','color',[0 0.4470 0.7410])
plot(MECO_WI,MECO_delta,'d','color',[0.93 0.69 0.13])
plot(post_WI,post_delta,'o','color',[0 0.5 0])
xlabel('Weathering intensity')
ylabel('\delta^7Li_{riv} (‰)')
legend('Pre MECO','MECO','Post MECO')

subplot(3,3,6)
hold on
box on
% plot(mc_outputs.means.WI,mc_outputs.means.delta_riv_Li,'k')
% plot(mc_outputs.min1.WI,mc_outputs.min1.delta_riv_Li,'color',col_ran)
% plot(mc_outputs.plus1.WI,mc_outputs.plus1.delta_riv_Li,'color',col_ran)
% xlabel('Weathering intensity')
% ylabel('\delta^7Li_{riv} (‰)')
plot(ntime,mc_outputs.means.WI,'k')
plot(ntime,mc_outputs.min1.WI,'color',col_ran)
plot(ntime,mc_outputs.plus1.WI,'color',col_ran)
xlabel('Weathering intensity')
ylabel('Weathering intensity')


%%%% Ocean Os
subplot(3,3,7)
hold on
box on
plot(ntime,mc_outputs.means.Os_conc_s,'r')
plot(ntime,mc_outputs.min1.Os_conc_s,'r--')
plot(ntime,mc_outputs.plus1.Os_conc_s,'r--')

plot(ntime,mc_outputs.means.Os_conc_h,'c')
plot(ntime,mc_outputs.means.Os_conc_d,'b')
xlabel('Time (Ma)')
ylabel('Dissolved Os (mol m^{-3})')

%%%% Os fluxes
subplot(3,3,8)
hold on
box on
river_os_mean = mc_outputs.means.F_ws_Os + mc_outputs.means.F_wg_Os;
river_os_min1 = mc_outputs.min1.F_ws_Os + mc_outputs.min1.F_wg_Os;
river_os_plus1 = mc_outputs.plus1.F_ws_Os + mc_outputs.plus1.F_wg_Os;
plot(ntime,river_os_mean,'r')
plot(ntime,river_os_min1,'r--')
plot(ntime,river_os_plus1,'r--')

plot(ntime,mc_outputs.means.F_lth_Os,'b')
plot(ntime,mc_outputs.means.F_hth_Os,'m')

plot(ntime,mc_outputs.means.F_sink_Os,'g')
plot(ntime,mc_outputs.min1.F_sink_Os,'g--')
plot(ntime,mc_outputs.plus1.F_sink_Os,'g--')
xlabel('Time (Ma)')
ylabel('Osmium fluxes (Mol yr^{-1})')

%%%% Os isotopes
subplot(3,3,9)
hold on
box on
% plot this model
plot(ntime,mc_outputs.means.dOs_s,'k')
plot(ntime,mc_outputs.min1.dOs_s,'color',col_ran)
plot(ntime,mc_outputs.plus1.dOs_s,'color',col_ran)
% if plotting the data
% errorbar(time1263,os1263,erros1263,'DisplayName','1263','MarkerSize',15,...
%     'MarkerFaceColor',dgreen,'Marker','.','LineStyle','none','Color',dgreen);
% errorbar(timeu1333,osu1333,errosu1333,'DisplayName','U1333','MarkerSize',15,...
%     'MarkerFaceColor',gold,'Marker','.','LineStyle','none','Color',gold);
% if plotting the running averages of combined sites
plot(timeboth,osavg,'color',lblue)
plot(timeboth,osmin,'c')
plot(timeboth,osmax,'c')
xlabel('Time (Ma)')
ylabel('^{187}Os/^{188}Os_{initial} (‰)')

figure

%%%% Erosion
subplot(2,2,1)
hold on
box on
plot(ntime,mc_outputs.means.f_R,'k')
plot(ntime,mc_outputs.min1.f_R,'color',col_ran)
plot(ntime,mc_outputs.plus1.f_R,'color',col_ran)
xlabel('Time (Ma)')
ylabel('Erosion (normalised)')
xlim([39 41.5])

%%%% Erosion (tonnes)
subplot(2,2,2)
hold on
box on
plot(ntime,mc_outputs.means.erosion_tonnes,'k')
plot(ntime,mc_outputs.min1.erosion_tonnes,'color',col_ran)
plot(ntime,mc_outputs.plus1.erosion_tonnes,'color',col_ran)
xlabel('Time (Ma)')
ylabel('Erosion (Tonnes yr^{-1})')
xlim([39 41.5])

%%%% Silicate weathering (tonnes)
subplot(2,2,3)
hold on
box on
plot(ntime,mc_outputs.means.F_ws_tonnes,'k')
plot(ntime,mc_outputs.min1.F_ws_tonnes,'color',col_ran)
plot(ntime,mc_outputs.plus1.F_ws_tonnes,'color',col_ran)
xlabel('Time (Ma)')
ylabel('Silicate weathering (Tonnes yr^{-1})')
xlim([39 41.5])

%%%% CO2 input (Mol yr-1)
subplot(2,2,4)
hold on
box on
plot(ntime,mc_outputs.means.CO2_input,'k')
plot(ntime,mc_outputs.min1.CO2_input,'color',col_ran)
plot(ntime,mc_outputs.plus1.CO2_input,'color',col_ran)
xlabel('Time (Ma)')
ylabel('Additional CO_2 input (Mol yr^{-1})')
xlim([39 41.5])

figure
%%%% Li concentration in the global ocean
subplot(1,2,1)
hold on
box on
plot(ntime,mc_outputs.means.Total_li,'k')
plot(ntime,mc_outputs.min1.Total_li,'color',col_ran)
plot(ntime,mc_outputs.plus1.Total_li,'color',col_ran)
xlabel('Time (Ma)')
ylabel('[Li]_{sw} (Mol)')
xlim([39 41.5])

%%%% Os concentration in the global ocean
subplot(1,2,2)
hold on
box on
plot(ntime,mc_outputs.means.Total_os,'k')
plot(ntime,mc_outputs.min1.Total_os,'color',col_ran)
plot(ntime,mc_outputs.plus1.Total_os,'color',col_ran)
xlabel('Time (Ma)')
ylabel('[Os]_{sw} (Mol)')
xlim([39 41.5])

figure
%%%% Plot all d7Li low latitude surface ocean at once
hold on
box on
for j = 1:n
plot(ntime,mc_outputs.d7Li_s(:,j))
end
xlabel('Time (Ma)')
ylabel('\delta^7Li_{sw} (‰)')


% figure
% %%%% Plot all Total Li in ocean at once
% hold on
% box on
% for j = 1:n
% plot(ntime,mc_outputs.Total_li(:,j))
% end
% xlabel('Time (Ma)')
% ylabel('[Li]_{sw} (Mol)')




